import * as newHomePage from '../../pages/actions/newHomePage';
import { setupEnvAndTestData } from '../../support/hooks';

describe("Verify Virtual Try-On Banner", () =>{

    setupEnvAndTestData();

    beforeEach(() => {
        cy.visit('/home-new')
        newHomePage.clickOnNoThanksButton()
        newHomePage.verifyUrlInclude('/home-new')
    });

    it("Verify virtual try-on banner should be visible", ()=>{
        newHomePage.verifyVirtualTryOnBannerIsVisible()
    });

    it("Verify virtual try-on banner should be navigate on virtual try-on eyeglasses page", ()=>{  
        newHomePage.clickOnVirtualTryOnBanner()
        newHomePage.verifyUrlInclude("/eyeglasses/virtual-try-on:yes")
    });
})