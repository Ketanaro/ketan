import * as newHomePage from '../../pages/actions/newHomePage';
import { setupEnvAndTestData } from '../../support/hooks';

describe("Verify Test Vision Banner", () =>{

    setupEnvAndTestData();

    beforeEach(() => {
        cy.visit('/home-new')
        newHomePage.clickOnNoThanksButton()
        newHomePage.verifyUrlInclude('/home-new')
    });

    it("Verify vision banner should be visible", ()=>{
        newHomePage.verifyTestVisionBannerIsVisible()
    });

    it("Verify vision banner should be navigate on Online Vision Test page", ()=>{  
        newHomePage.clickOnTestVisionBanner()
        newHomePage.verifyUrlInclude("/online-vision-test")
    });
})