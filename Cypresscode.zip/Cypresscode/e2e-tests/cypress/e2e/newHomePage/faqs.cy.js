import * as newHomePage from '../../pages/actions/newHomePage';
import { setupEnvAndTestData } from '../../support/hooks';

describe("Verify FAQs", () =>{

    setupEnvAndTestData();

   beforeEach(() => {
        cy.visit('/home-new')
        newHomePage.clickOnNoThanksButton()
        newHomePage.verifyUrlInclude('/home-new')
    });

    it("Verify main image should be visible", ()=>{
        newHomePage.verifyMainImageIsVisible()
    });

    it("Verify title text, font size and its color", ()=>{
        newHomePage.verifyTitleTextOfFAQs("FAQs")
        newHomePage.verifyFAQTitleFontSize('30px')
        newHomePage.verifyFAQTitleFontColor('rgb(49, 48, 48)')
    });

    it("Verify View All button visible text, font size and its color", ()=>{
        newHomePage.verifyTextOfViewAllButton("View all")
        newHomePage.verifyViewAllButtonFontSize('14px')
        newHomePage.verifyViewAllButtonColor('rgb(49, 48, 48)')
    });

    it("Verify maximum 6 FAQs should be visible", ()=>{
        newHomePage.verifyFAQsLength(6)
    });

    it("Verify click event to close and open FAQ question", ()=>{
        newHomePage.clickOnFAQsQuestionsBySequnceNumber(1)
        newHomePage.verifyFAQsShouldBeOpenedBySequenceNumber(1)
        newHomePage.clickOnFAQsQuestionsBySequnceNumber(1)
        newHomePage.verifyFAQsShouldBeClosedBySequenceNumber(1)
    });

    it("Verify only one FAQs should be opened", ()=>{
        newHomePage.clickOnFAQsQuestionsBySequnceNumber(1)
        newHomePage.verifyFAQsShouldBeOpenedBySequenceNumber(1);
        [0,2,3,4,5].forEach((index) => {
            newHomePage.verifyFAQsShouldBeClosedBySequenceNumber(index);
        });
    });

    it("Verify View All button should be navigate on all FAQs page", ()=>{  
        newHomePage.clickOnViewAllButton()
        newHomePage.verifyLisOfFAQsAreVisible()
        newHomePage.verifyUrlInclude('/help/faq')
    });
})