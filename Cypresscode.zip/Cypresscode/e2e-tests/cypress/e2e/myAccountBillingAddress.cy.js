import { setupEnvAndTestData } from '../support/hooks';
import * as loginPage from '../pages/actions/loginPage';
import * as billingAddress from '../pages/actions/myAccountBillingAddress'
import * as shippingAddress  from '../pages/actions/myAccountShippingAddress'

describe('Test Scenarios for Editing Billing Address', () => {
  setupEnvAndTestData()

  let TESTDATA, CONSTANTS;  //Load the data from based on the Env. and Constants.
  beforeEach('Visit the URL',()=> {
    cy.visit('/')
      loginPage.navigateToLoginScreen()
      TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
      CONSTANTS = Cypress.env('constants') //Load the validation Message
      loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password); //Login into application with valid cred.
      loginPage.verifyLoginSuccessMessage(CONSTANTS.loginPass)
    });

    it("Test Billing Address for United States Address", () => {
      cy.visit("/account/address-and-payment");
      billingAddress.addBillingAddress()
      billingAddress.firstNameBilling()
      billingAddress.lastNameBilling()
      shippingAddress.addCompanyButton()
      billingAddress.companyNameBilling()
      billingAddress.companyAddress1Billing()
      billingAddress.cityBilling()
      billingAddress.stateBilling()
      billingAddress.pincodeBilling()
      billingAddress.phoneNumberBilling()
      billingAddress.saveButtonBilling()
    });
    it("Test Billing address for other countries", () => {
      cy.visit("/account/address-and-payment");
      billingAddress.addBillingAddress()
      billingAddress.internationalBillingAddress()
      //billingAddress.countryBilling()  //--Country missing in dropdown on local
      billingAddress.firstNameBilling()
      billingAddress.lastNameBilling()
      shippingAddress.addCompanyButton()
      billingAddress.companyNameBilling()
      billingAddress.companyAddress1Billing()
      billingAddress.cityBilling()
      billingAddress.internationalStateBilling()
      billingAddress.pincodeBilling()
      billingAddress.phoneNumberBilling()
      billingAddress.saveButtonBilling()
    });
  })