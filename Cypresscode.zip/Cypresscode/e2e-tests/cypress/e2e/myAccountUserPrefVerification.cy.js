/*
Implementation of PL-32: My Account - Edit section - Validations
From this Spec file, we will verify each field by changing the User data.
*/
import { accountInfo } from "../pages/actions/myAccountUpdatePage"
import * as loginPage from '../pages/actions/loginPage';
import { setupEnvAndTestData } from "../support/hooks";
import { EditInformation } from "../fixtures/myAccountInfo.json"

const My_Account_Update = new accountInfo() //Variable to get the values of Elements for My Profile.

describe('TS: My Profile - User Preferences',() => {
    setupEnvAndTestData()
    let TESTDATA, CONSTANTS; //Load the data from based on the Env.
    beforeEach('',() => {
        cy.visit('/account/sign-in')
        TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
        CONSTANTS = Cypress.env('constants')
        loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password) //Load the data based on the Env.
        My_Account_Update.profileEditLink();
    })
    it('TC: Verify the validation message for First Name',() => {
        My_Account_Update.profileFNameClr();
        My_Account_Update.profileLName(EditInformation.UserLname);
        My_Account_Update.profileSaveBtn();
        My_Account_Update.profileFirstLastNameAlert(CONSTANTS.myAccountMsg.ProfileFNameAlert);
    })

    it('TC: Verify the validation message for Last Name',() => {
        My_Account_Update.profileFName(EditInformation.UserFname);
        My_Account_Update.profileLNameClr();
        My_Account_Update.profileSaveBtn();
        My_Account_Update.ProfileLNameAlert(CONSTANTS.myAccountMsg.ProfileLNameAlert);
    })
});