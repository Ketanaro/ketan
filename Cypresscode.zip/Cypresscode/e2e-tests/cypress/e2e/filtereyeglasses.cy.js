import { eyeglassFilterFunction } from "../pages/actions/filtereyeglassesPage";
import { setupEnvAndTestData } from "../support/hooks";

const FILTER_EYEGLASSES = new eyeglassFilterFunction();

describe("Eyeglasses Filters Scenarios", function () {
  setupEnvAndTestData()

  it("Test Filters for Eyeglasses ", function () {
    FILTER_EYEGLASSES.navigateToEyeglasses()

    //Visiblity of Gender Radio buttons
    FILTER_EYEGLASSES.GenderMale();
    FILTER_EYEGLASSES.GenderFemale();
    FILTER_EYEGLASSES.GenderChildren();

    //Visibility of checkbox for Price
    FILTER_EYEGLASSES.PriceUnder99();
    FILTER_EYEGLASSES.PriceUnder149();
    FILTER_EYEGLASSES.PriceUnder199();
    FILTER_EYEGLASSES.PriceAbove200();
    FILTER_EYEGLASSES.PriceAny();

    //Visibility of checkbox for Frames Shapes
    FILTER_EYEGLASSES.ShapeAviator();
    FILTER_EYEGLASSES.ShapeCatEye();
    FILTER_EYEGLASSES.ShapeOval();
    FILTER_EYEGLASSES.ShapeRectangle();
    FILTER_EYEGLASSES.ShapeRound();
    FILTER_EYEGLASSES.ShapeSquare();

    //visibility of checkbox for Frame Types
    FILTER_EYEGLASSES.FrameTypeRimless();
    FILTER_EYEGLASSES.FrametypeSemiRimless();
    FILTER_EYEGLASSES.FrameTypeFullFrame();

    //Visibility of checkbox for Material
    FILTER_EYEGLASSES.MaterialMetal();
    FILTER_EYEGLASSES.MaterialPlastic();

    //Visibility of Size dropdowns
    FILTER_EYEGLASSES.LensWidth();
    FILTER_EYEGLASSES.BridgeWidth();
    FILTER_EYEGLASSES.ArmLength();

    //Visibility of Any Size button
    FILTER_EYEGLASSES.AnySizeButton();

    //Selecting radio button for Gender
    FILTER_EYEGLASSES.GenderFemale();
    FILTER_EYEGLASSES.GenderMale();
    FILTER_EYEGLASSES.GenderChildren();

    //Selecting single checkbox for Price
    FILTER_EYEGLASSES.PriceUnder99().click({ force: true });

    //Selecting single checkbox for Frames Shapes
    FILTER_EYEGLASSES.ShapeOval().click({ force: true });

    //Selecting checkbox for Frame Types
    FILTER_EYEGLASSES.FrameTypeRimless().click({ force: true });

    //Reset all filters
    FILTER_EYEGLASSES.ResetFilter().click({ force: true });
  });
});
