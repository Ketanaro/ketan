/*
Implementation of PL-32: My Account - Edit section - Validations
From this Spec file, we will verify each field by changing the User data.
*/
import { accountInfo } from "../pages/actions/myAccountUpdatePage"
import myAccountInfo  from '../fixtures/myAccountInfo.json'
import * as loginPage from '../pages/actions/loginPage';
import { setupEnvAndTestData } from "../support/hooks";

const My_Account_Update = new accountInfo() //Variable to get the values of Elements for My Profile.

describe('TS: My Profile - Password Validation',() => {
   
    setupEnvAndTestData()

    let TESTDATA, CONSTANTS; //Load the data from based on the Env.
    beforeEach('Navigate the Ez Application and Login',() => {
        cy.visit('/account/sign-in')
        TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
        CONSTANTS = Cypress.env('constants')
        loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password) //Load the data based on the Env.
        My_Account_Update.profileEditLink();
    })

    //Verify the validation message for Password Sections
    it('Verify the impact by keeping blank OLD Password field', () => {
        My_Account_Update.profileNewPass(myAccountInfo.EditInformation.UserNewPass);
        My_Account_Update.profileConfirmPass(myAccountInfo.EditInformation.UserNewPass);
        My_Account_Update.profileSaveBtn();
        My_Account_Update.profileOldPassValidation(CONSTANTS.myAccountMsg.ProfileOldPasswordAlert);
    });
    
    //Validation message is not accurate on the UI side, once it is done we can run this part.
    it.skip('Verify the impact by setting a different Password for New and Confirm Password', () => {
        My_Account_Update.profileNewPass(TESTDATA.users.password);
        My_Account_Update.profileConfirmPass(myAccountInfo.EditInformation.UserOldPass);
        My_Account_Update.profileOldPass(TESTDATA.users.password);
        My_Account_Update.profileSaveBtn();
        My_Account_Update.profilePasswordMismatch(CONSTANTS.myAccountMsg.profilePasswordMismatch);
    });
    
    //Validation message is not accurate on the UI side, once it is done we can run this part.
    it.skip('Verify the impact by entering invalid Password for New and Confirm Password', () => {
        My_Account_Update.profileNewPass(myAccountInfo.EditInformation.UserPass1);
        My_Account_Update.profileConfirmPass(myAccountInfo.EditInformation.UserPass2);
        My_Account_Update.profileOldPass(TESTDATA.users.password);
        My_Account_Update.profileSaveBtn();
        My_Account_Update.profileInvalidPassSetup(CONSTANTS.myAccountMsg.profileInvalidPassSetup);
    });
});