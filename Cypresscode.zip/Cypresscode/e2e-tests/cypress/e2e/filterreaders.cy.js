import { readerFilterFunction } from "../pages/actions/filterreadersPage";
import { setupEnvAndTestData } from "../support/hooks";

const FILTER_READERS = new readerFilterFunction();

describe("Readers Filters Test", function () {
  setupEnvAndTestData()

  it("Test filters for Readers", function () {
    FILTER_READERS.navigateToReaders();

    //Visiblity of Gender Radio buttons
    FILTER_READERS.GenderMale();
    FILTER_READERS.GenderFemale();

    //Visibility of checkbox for Price
    FILTER_READERS.PriceUnder99();
    FILTER_READERS.PriceUnder149();
    FILTER_READERS.PriceUnder199();
    FILTER_READERS.PriceAbove200();
    FILTER_READERS.PriceAny();

    //Visibility of checkbox for Frames Shapes
    FILTER_READERS.ShapeCatEye();
    FILTER_READERS.ShapeRectangle();

    //visibility of checkbox for Frame Types
    FILTER_READERS.FrametypeRimless();
    FILTER_READERS.FrameTypeFullFrame();

    //Visibility for Size filters
    FILTER_READERS.LensWidth();

    FILTER_READERS.BridgeWidth();
    FILTER_READERS.ArmLength();

    //Visibility of Any Size button
    FILTER_READERS.AnySizeButton();

    //Selecting radio button for Gender
    FILTER_READERS.GenderFemale().click({ force: true });
    FILTER_READERS.GenderMale().should("not.be.checked");

    //Selecting single checkbox for Price
    FILTER_READERS.PriceUnder149().click({ force: true });

    //Selecting single frame shape
    FILTER_READERS.ShapeRectangle().click({ force: true });

    //Reset all filters
    FILTER_READERS.ResetFilter().click({ force: true });
  });
});
