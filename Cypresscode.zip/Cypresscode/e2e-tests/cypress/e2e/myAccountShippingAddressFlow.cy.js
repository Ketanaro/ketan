import { setupEnvAndTestData } from '../support/hooks';
import * as loginPage from '../pages/actions/loginPage';
import * as shippingAddress  from '../pages/actions/myAccountShippingAddress'

describe('Test Scenarios for Editing Shipping Address', () => {
  setupEnvAndTestData()

  let TESTDATA, CONSTANTS;  //Load the data from based on the Env. and Constants.
  beforeEach('Visit the URL',()=> {
    cy.visit('/')
      loginPage.navigateToLoginScreen()
      TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
      CONSTANTS = Cypress.env('constants') //Load the validation Message
      loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password); //Login into application with valid cred.
      loginPage.verifyLoginSuccessMessage(CONSTANTS.loginPass)
    });

    it("Test Shipping Address for United States Address", () => {
      cy.visit("/account/address-and-payment");
      shippingAddress.addShippingAddress()
      shippingAddress.firstName()
      shippingAddress.lastName()
      shippingAddress.addCompanyButton()
      shippingAddress.companyName()
      shippingAddress.companyAddress1()
      shippingAddress.city()
      shippingAddress.state()
      shippingAddress.pincode()
      shippingAddress.phoneNumber()
      shippingAddress.submitButton()
    });
    it("Test shipping address for other countries", () => {
      cy.visit("/account/address-and-payment");
      shippingAddress.addShippingAddress()
      shippingAddress.internationalAddress()
      shippingAddress.country()
      shippingAddress.firstName()
      shippingAddress.lastName()
      shippingAddress.addCompanyButton()
      shippingAddress.companyName()
      shippingAddress.companyAddress1()
      shippingAddress.city()
      shippingAddress.internationalState()
      shippingAddress.pincode()
      shippingAddress.phoneNumber()
      shippingAddress.submitButton()
    });
  })