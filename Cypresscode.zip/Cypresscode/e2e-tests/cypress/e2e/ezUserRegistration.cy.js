/*implemtation for PL-28,PL-31
This Spec file covers the:
-> We will create the new user, and User data will dynamically generated using
   'registerNewUser' function.
-> We dont require any fixture file to manage the data.
-> To run the script in Production, Replace the Email parameter.
*/

import { setupEnvAndTestData } from '../support/hooks';
import { registerUser } from "../pages/actions/userRegistration";

const EZ_USER_REG = new registerUser()

describe.skip('TS: Verify the New User Registration',() => {

    setupEnvAndTestData()

    //This block will call before all the Test case.
    beforeEach('Navigate to the Login Page URL',() => {
        cy.visit('/account/sign-in')
        EZ_USER_REG.signInnewCustRadbtn()
    })

    //Fill out all the infomation and submit the details
    it('TC:Fill up the infomration on registration page', () => {
        cy.registerNewUser()
    })

    //Uncheck all the checkbox and verify the asseration
    it('TC:Verify the checkbox properties on the Sign Up page',()=>{
        EZ_USER_REG.verifyChkPropeties()
    })

    //Click on the eye icon and show the typed password.
    //Marking this block as skipped as it is environment dependednt and works on staging only currently
    it.skip('TC:Verify the Password visible icon',()=>{
        cy.generateData().then((userData) =>{
            EZ_USER_REG.regPasswordVisibility()
            EZ_USER_REG.regConPasswordVisibility(userData.signUpPassvisible)
        })
    })
})