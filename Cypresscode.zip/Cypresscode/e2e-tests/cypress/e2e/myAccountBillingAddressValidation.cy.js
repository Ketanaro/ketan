import { setupEnvAndTestData } from '../support/hooks';
import * as loginPage from '../pages/actions/loginPage';
import * as billingAddress from '../pages/actions/myAccountBillingAddress'
import * as shippingAddress  from '../pages/actions/myAccountShippingAddress'

describe('Test Scenarios for Validation of BIlling Address', () => {
  setupEnvAndTestData()

  let TESTDATA, CONSTANTS;  //Load the data from based on the Env. and Constants.
  beforeEach('Visit the URL',()=> {
    cy.visit('/')
      loginPage.navigateToLoginScreen()
      TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
      CONSTANTS = Cypress.env('constants') //Load the validation Message
      loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password); //Login into application with valid cred.
      loginPage.verifyLoginSuccessMessage(CONSTANTS.loginPass)
    });

    it("Test Validation message for US billing address ", () => {
      cy.visit("/account/address-and-payment");
      billingAddress.addBillingAddress()
      billingAddress.saveButtonBilling()
      shippingAddress.errorModal()
      shippingAddress.thanksButton()
      billingAddress.firstNameErrorBilling()
      billingAddress.lastNameErrorBilling()
      billingAddress.companyAddress1ErrorBilling()
      billingAddress.cityErrorBilling()
      billingAddress.pincodeErrorBilling()
      billingAddress.phoneNumberErrorBilling()
    });
    it("Test validation for other countries billing address", () => {
      cy.visit("/account/address-and-payment");
      billingAddress.addBillingAddress()
      billingAddress.internationalBillingAddress()
      billingAddress.saveButtonBilling()
      shippingAddress.errorModal()
      shippingAddress.thanksButton()
      billingAddress.firstNameErrorBilling()
      billingAddress.lastNameErrorBilling()
      billingAddress.companyAddress1ErrorBilling()
      billingAddress.cityErrorBilling()
      billingAddress.pincodeErrorBilling()
      billingAddress.phoneNumberErrorBilling()
    });
  })