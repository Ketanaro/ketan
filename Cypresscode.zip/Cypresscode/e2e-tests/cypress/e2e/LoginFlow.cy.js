import { setupEnvAndTestData } from '../support/hooks'
import * as loginPage from '../pages/actions/loginPage';
import { LOCATORS } from "../pages/locators/loginPageLocators";

describe('TS: Verify the Login Flow ',() => {

    setupEnvAndTestData()

    let TESTDATA, CONSTANTS;  //Load the data from based on the Env. and Constants.
    beforeEach('Visit the URL',()=> {
        cy.visit('/')
        loginPage.navigateToLoginScreen()
        TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
        CONSTANTS = Cypress.env('constants') //Load the validation Messages
    })

    it('Verify the logo on the Login Page', () => {
        loginPage.verifyLogoIsVisible()  //Login Page - Verify Logo
    })

    it('Login with Valid credentials', () => {
        loginPage.verifyUsernameIsVisible(); //Login Page - UserName field visible
        loginPage.verifyPasswordIsVisible(); //Login Page - Password field visible
        loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password); //Login into application with valid cred.
        loginPage.verifyLoginSuccessMessage(CONSTANTS.loginPass);
    })

    it('Login with Invalid credentials', () => {
        loginPage.verifyUsernameIsVisible(); //Login Page - UserName field visible
        loginPage.verifyPasswordIsVisible(); //Login Page - Password field visible
        loginPage.loginToEzContacts('test@ablc.com','invalidpassword');  //Login Page- Enter invalid cred.
        loginPage.verifyAuthErrorMessage(CONSTANTS.authErrorMsg);
    })

    it("Verify validation w/o entering the Username and Password", () => {
        cy.clickOnElement(LOCATORS.login.signInBtn) //Login Page - Clicking on the signin Button
        cy.getTextOfElementandVerify(LOCATORS.login.username,CONSTANTS.loginPageEmail)
    })

    it("Verify validation w/o entering the Username", () => {
        cy.typeTextToElement(LOCATORS.login.password,TESTDATA.users.password)
        cy.clickOnElement(LOCATORS.login.signInBtn) //Login Page - Clicking on the signin Button
        cy.getTextOfElementandVerify(LOCATORS.login.username,CONSTANTS.loginPageEmail)  //Verify the validation message for UserName field
    })

    it("Verify validation w/o entering the Password", () => {
        cy.typeTextToElement(LOCATORS.login.username,TESTDATA.users.username)
        cy.clickOnElement(LOCATORS.login.signInBtn) //Login Page - Clicking on the signin Button
        cy.getTextOfElementandVerify(LOCATORS.login.password, CONSTANTS.loginPagePassValidation)  //Verify the validation message for Password field
    })
})