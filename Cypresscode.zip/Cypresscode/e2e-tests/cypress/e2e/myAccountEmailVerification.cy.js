/*
Implementation of PL-32: My Account - Edit section - Validations
From this Spec file, we will verify each field by changing the User data.
*/
import { accountInfo } from "../pages/actions/myAccountUpdatePage"
import myAccountInfo  from '../fixtures/myAccountInfo.json'
import * as loginPage from '../pages/actions/loginPage';
import { setupEnvAndTestData } from "../support/hooks";


const My_Account_Update = new accountInfo() //Variable to get the values of Elements for My Profile.

describe.skip('TS: My Profile - Email Verification',() => {
    
    setupEnvAndTestData()
    
    let TESTDATA, CONSTANTS; //Load the data from based on the Env.
    beforeEach('Navigate the Ez Application and Login',() => {
        cy.visit('/account/sign-in')
        TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
        CONSTANTS = Cypress.env('constants')
        loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password) //Load the data based on the Env.
        My_Account_Update.profileEditLink();
    })

    //Verify the validation message for Email Prefrences:
    it('Verify the impact by Entering the Invalid Email Address(New Email Field).', () => {
        My_Account_Update.profileNewEmail(myAccountInfo.EditInformation.UserInvalidEmail1);
        My_Account_Update.profileSaveBtn()
        My_Account_Update.ProfileNewEmailAlert(CONSTANTS.myAccountMsg.ProfileNewEmailAlert);
    });

    it('Verify the impact by providing the Different Email Address for New and Confirm Email Text Field.', () => {
        My_Account_Update.profileNewEmail(myAccountInfo.EditInformation.UserInvalidEmail1);
        My_Account_Update.profileConfirmEmail(myAccountInfo.EditInformation.UserInvalidEmail2);
        My_Account_Update.profileSaveBtn()
        My_Account_Update.ProfileConfrimEmailAlert(CONSTANTS.myAccountMsg.ProfileSingleEmailAlert);
    });

    it('Verify the impact by providing value only for Confirm Email text field.', () => {
        My_Account_Update.profileConfirmEmail(myAccountInfo.EditInformation.UserInvalidEmail2);
        My_Account_Update.profileSaveBtn()
        My_Account_Update.ProfileSingleEmailAlert(CONSTANTS.myAccountMsg.ProfileSingleEmailAlert);
    });
});