import AddToCart from "../fixtures/AddToCart.json"
import { ProductDetailsElements } from "../pages/actions/ProductDetailsPage"
import { ProductBasketElements } from "../pages/actions/ProductBasketPage"
import * as loginPage from '../pages/actions/loginPage';
import { setupEnvAndTestData } from "../support/hooks";

const productDetails = new ProductDetailsElements()
const productBasket = new ProductBasketElements()

describe('Test the Add To Cart Flow', () => {
    setupEnvAndTestData()

    it('Verify User can add sunglasses to cart', () => {
        cy.visit("/product/sunglasses/323932/wiley-x-blink")

        //Select frame and color
        productDetails.selectFrameAndColor(AddToCart.SunglassProductDetails.frameSize,AddToCart.SunglassProductDetails.color)

        //Click add to cart
        productDetails.addToCartButton()

        //Validate success message
        productBasket.successMsgCart(AddToCart.Messages.AddToCartSuccessfully)
    })

    it('Verify User can add Eyeglasses to cart', () => {
        cy.visit("/product/eyeglasses/324352/spine-sp2004")
        //cy.reload(true)

        //Select frame and color
        productDetails.selectFrameAndColor(AddToCart.EyeglassProductDetails.frameSize,AddToCart.EyeglassProductDetails.framecolor)

        //Select prescription type
        productDetails.selectPrescriptionType(AddToCart.EyeglassProductDetails.lensType)

        //Fill Prescription details for Right eye
        productDetails.selectRightEyeDetails(AddToCart.prescriptionDetails.rightSphereValue,
            AddToCart.prescriptionDetails.rightCylinderValue,
            AddToCart.prescriptionDetails.rightAxisValue)

        //Fill Prescription details for Left eye
        productDetails.selectLeftEyeDetails(AddToCart.prescriptionDetails.leftSphereValue,
            AddToCart.prescriptionDetails.leftCylinderValue,
            AddToCart.prescriptionDetails.leftAxisValue)

        //Fill pupil, lens material, coating and lens color
        productDetails.selectPupil_Material_Coating_Color(AddToCart.prescriptionDetails.pDpupilDistance,AddToCart.EyeglassProductDetails.lensMaterial,
            AddToCart.EyeglassProductDetails.antiReflectiveCoating,
            AddToCart.EyeglassProductDetails.lensColor)

         //Move next to Material
         productDetails.moveNextToMaterial()

         //Select Material
         productDetails.materialSelection(AddToCart.EyeglassProductDetails.lensMaterial)

         //Move next to coating
         productDetails.moveNextToCoatings()

         //Select Coating
         productDetails.coatingSelection(AddToCart.EyeglassProductDetails.antiReflectiveCoating)

         //Move next to lens color
         productDetails.moveNextToLensColor()

         //select Lens Color
         productDetails.lensColor(AddToCart.EyeglassProductDetails.lensColor)


        //Click on Complete button
        productDetails.completeButton()

        //Click add to cart
        productDetails.addToCartButton()

        //Verify success message
        productBasket.successMsgCart(AddToCart.Messages.AddToCartSuccessfully)
    })

    it('Verify User can add contact lens to cart', () => {
        cy.visit("product/contact-lenses/446099/soflens-1-day")

        //Select contact lens details
        productDetails.selectContactLensDetails(AddToCart.ContactLensProductDetails.rightEyePower,AddToCart.ContactLensProductDetails.leftEyePower)

        //Select Boxes for Left and right eye
        productDetails.selectContactsBoxes(AddToCart.ContactLensProductDetails.rightBoxes,AddToCart.ContactLensProductDetails.leftBoxes)

        //Click add to cart
        productDetails.addToCartButtonContactLens()

        //Verify success message
        productBasket.successMsgCart(AddToCart.Messages.AddToCartSuccessfully)
    })
})