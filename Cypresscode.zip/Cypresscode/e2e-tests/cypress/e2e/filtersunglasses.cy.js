import { filterSunglasses } from "../pages/actions/filtersunglassesPage";
import { setupEnvAndTestData } from "../support/hooks";

const FILTER_SUNGLASSES = new filterSunglasses;

describe("Sunglasses Filters Test", function() {
  setupEnvAndTestData()

    it("Test Filters for Sunglasses", function()  {
      FILTER_SUNGLASSES.navigateToSunglasses();

      //Visiblity of Gender Radio buttons
      FILTER_SUNGLASSES.GenderMale()
      FILTER_SUNGLASSES.GenderFemale()
      FILTER_SUNGLASSES.GenderChildren()

      //Visibility of Categories filter
      FILTER_SUNGLASSES.CategoryPrescriptionCapable()

      //Visibility of checkbox for Price
      FILTER_SUNGLASSES.PriceUnder99()
      FILTER_SUNGLASSES.PriceUnder149()
      FILTER_SUNGLASSES.PriceUnder199()
      FILTER_SUNGLASSES.PriceAbove200()
      FILTER_SUNGLASSES.PriceAny()


      //Visibility of checkbox for Frames Shapes
      FILTER_SUNGLASSES.ShapeAviator()
      FILTER_SUNGLASSES.ShapeCatEye()
      FILTER_SUNGLASSES.ShapeOval()
      FILTER_SUNGLASSES.ShapeRectangle()
      FILTER_SUNGLASSES.ShapeRound()
      FILTER_SUNGLASSES.ShapeSquare()

      //visibility of checkbox for Frame Types
      FILTER_SUNGLASSES.FrameTypeRimless()
      FILTER_SUNGLASSES.FrameTypeFullFrame()

      //Visibility of filters for material
      FILTER_SUNGLASSES.MaterialPlastic()

      //Visibility for Size filters
      FILTER_SUNGLASSES.LensWidth()
      FILTER_SUNGLASSES.BridgeWidth()
      FILTER_SUNGLASSES.ArmLength()

      //Visibility of Any Size button
      FILTER_SUNGLASSES.AnySizeButton()

      //Selecting radio button for Gender
      FILTER_SUNGLASSES.GenderFemale()
                      .click({force: true});
      FILTER_SUNGLASSES.GenderMale()
                      .should('not.be.checked');
      FILTER_SUNGLASSES.GenderChildren()
                      .should('not.be.checked');

      //Selecting single checkbox for Price
      FILTER_SUNGLASSES.PriceUnder149()
                      .click({force: true});

      //Selecting single frame shape
      FILTER_SUNGLASSES.ShapeRectangle()
                      .click({force: true});

      //Reset all filters
      FILTER_SUNGLASSES.ResetFilter()
                       .click({force: true});

    });
  });