import { setupEnvAndTestData } from '../support/hooks';
import * as loginPage from '../pages/actions/loginPage';
import * as shippingAddress  from '../pages/actions/myAccountShippingAddress'

describe('Test Scenarios for Validation of Shipping Address', () => {
  setupEnvAndTestData()

  let TESTDATA, CONSTANTS;  //Load the data from based on the Env. and Constants.
  beforeEach('Visit the URL',()=> {
    cy.visit('/')
      loginPage.navigateToLoginScreen()
      TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
      CONSTANTS = Cypress.env('constants') //Load the validation Message
      loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password); //Login into application with valid cred.
      loginPage.verifyLoginSuccessMessage(CONSTANTS.loginPass)
    });

    it("Test Validation message for US shipping address ", () => {
      cy.visit("/account/address-and-payment");
      shippingAddress.addShippingAddress()
      shippingAddress.submitButton()
      shippingAddress.errorModal()
      shippingAddress.thanksButton()
      shippingAddress.firstNameError()
      shippingAddress.lastNameError()
      shippingAddress.companyAddress1Error()
      shippingAddress.cityError()
      shippingAddress.pincodeError()
      shippingAddress.phoneNumberError()
    });
    it("Test validation for other countries shipping address", () => {
      cy.visit("/account/address-and-payment");
      shippingAddress.addShippingAddress()
      shippingAddress.internationalAddress()
      shippingAddress.submitButton()
      shippingAddress.errorModal()
      shippingAddress.thanksButton()
      shippingAddress.firstNameError()
      shippingAddress.lastNameError()
      shippingAddress.companyAddress1Error()
      shippingAddress.cityError()
      shippingAddress.pincodeError()
      shippingAddress.phoneNumberError()
    });
  })