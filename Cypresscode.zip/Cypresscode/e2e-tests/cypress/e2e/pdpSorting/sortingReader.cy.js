/*
Implementation of PL-34: Sorting functionality
From this Spec file, we will verify the Sorting functionality
from the CONTACT LENS listing page.

NOTE: Follow below steps to run this spec in Production Env.
1. Remove ".skip" from Production Describe and add ".skip" for Staging describe
2. Pass the Prod. value under the config. file.
*/

import { setupEnvAndTestData } from "../../support/hooks";
import { sortFunction } from "../../pages/actions/sortingFunctionalityPage"
import pdpSortingValues from "../../fixtures/pdpSortingValues.json"

const SORT_ELEMENT = new sortFunction();

describe.only('STAGING - Sorting Functionality on Reader Page',() => {
        
    setupEnvAndTestData()

    beforeEach('Navigate the the URL',()=>{
        cy.visit('/')
       SORT_ELEMENT.navigateToReaders() //Navigate to the Readers Page.
    })
    
    it('Verify the total values in Sorting Droprown', () =>{
        SORT_ELEMENT.sortingValues(); //To check the total values from the Dropdown.
    })
    
    it('Verify the sorting by: '+pdpSortingValues.sortByNew, () => {
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByNew) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyNewestSort(); //Here, verified that records are sorted or not.
    })
    
    it('Verify the sorting by: '+pdpSortingValues.sortByLowPrice, () => {        
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByLowPrice) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyLowPriceSort(); //Here, verified that records are sorted or not.
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByHighPrice, () => {
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByHighPrice) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyHighPriceSort(); //Here, verified that records are sorted or not.
    })

    it('Verify the sorting by: ' +pdpSortingValues.sortByBestSelling, () => {  
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByBestSelling) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyBestsellingReader(); //Here, verified that records are sorted or not.
    })
})

describe.skip('PRODUCTION - Sorting Functionality on Reader Page',() => {
    
    setupEnvAndTestData()

    beforeEach('Navigate the the URL',()=>{
        SORT_ELEMENT.navigateToReaders() //Navigate to the Readers Page.
    })

    it('Verify the values from the Sorting Dropdown', () => {
        SORT_ELEMENT.sortingReaderValue(); //Verifing the total values in the Dropdown.
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByBestSelling,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByBestSelling)
        SORT_ELEMENT.verifyBestsellingReader() //Verifing that records are sorted by "BestSelling" 
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByNew,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByNew)
        SORT_ELEMENT.verifyNewestSort() //Verifing that records are sorted by "Newest"
    })

    it('Verify the sorting by: ' +pdpSortingValues.sortByLowPrice,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByLowPrice)
        SORT_ELEMENT.verifyLowPriceSort() //Verifing that records are sorted by "Price: Low to High"
    })

    it('Verify the sorting by: ' +pdpSortingValues.sortByHighPrice,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByHighPrice)
        SORT_ELEMENT.verifyHighPriceSort() //Verifing that records are sorted by "Price: High to Low"
    })
})