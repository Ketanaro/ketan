/*
Implementation of PL-34: Sorting functionality
From this Spec file, we will verify the Sorting functionality
from the EYEGLASSES listing page.

NOTE: Follow below steps to run this spec in Production Env.
1. Remove ".skip" from Production Describe and add ".skip" for Staging describe
2. Pass the Prod. value under the config. file.
*/

import { setupEnvAndTestData } from "../../support/hooks";
import { sortFunction } from "../../pages/actions/sortingFunctionalityPage"
import pdpSortingValues from "../../fixtures/pdpSortingValues.json"

const SORT_ELEMENT = new sortFunction();

describe.only('STAGING - Sorting Functionality on Eyeglasses Page',() => {
    
    setupEnvAndTestData()

    beforeEach('Navigate the the URL',()=>{
        cy.visit('/')
      SORT_ELEMENT.navigateToEyeglasses() //Navigate to the Eyeglasses Page.
    })
    
    it('Verify the total values in Sorting Droprown', () =>{
        SORT_ELEMENT.sortingValues(); //To check the total values from the Dropdown.
    })
    
    it('Verify the sorting by: ' +pdpSortingValues.sortByNew, () => {
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByNew) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyNewestSort(); //Here, verified that records are sorted or not.
    })
    
    it('Verify the sorting by: ' +pdpSortingValues.sortByLowPrice , () => {        
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByLowPrice) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyLowPriceSort(); //Here, verified that records are sorted or not.
    })

    it('Verify the sorting by: ' +pdpSortingValues.sortByHighPrice, () => {
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByHighPrice) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyHighPriceSort(); //Here, verified that records are sorted or not.
    })

    it('Verify the sorting by: ' +pdpSortingValues.sortByBestSelling, () => {  
        SORT_ELEMENT.sortOrder(pdpSortingValues.sortByBestSelling) //selecting the value from Dropdown.
        SORT_ELEMENT.verifyBestsellingEye(); //Here, verified that records are sorted or not.
    })
})

describe.skip('PRODUCTION - Sorting Functionality on Eyeglasses Page',() => {
   
    setupEnvAndTestData()

    beforeEach('Navigate the the URL',()=>{
        SORT_ELEMENT.navigateToEyeglasses() //Navigate to the Eyeglasses Page.
    })

    it('Verify the values from the Sorting Dropdown', () => {
        SORT_ELEMENT.prodSortValues(); //Verifing the total values in the Dropdown.
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByBestMatch,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByBestMatch)
        SORT_ELEMENT.verifyBestsellingEye() //Verifing that records are sorted by "Best Match" 
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByPopulatiry,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByPopulatiry)
        SORT_ELEMENT.verifyPopularity() //Verifing that records are sorted by "Popularity"
    })
    
    it('Verify the sorting by: '+pdpSortingValues.sortByNew,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByNew)
        SORT_ELEMENT.verifyNewestSort() //Verifing that records are sorted by "Newest"
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByNameAZ,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByNameAZ)
        SORT_ELEMENT.verifyNameAZ() //Verifing that records are sorted by "Name : A-Z"
    })

    it('Verify the sorting by: '+pdpSortingValues.sortByNameZA,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByNameZA)
        SORT_ELEMENT.verifyNameZA() //Verifing that records are sorted by "Name Z-A"
    })   

    it('Verify the sorting by: ' +pdpSortingValues.sortByPriceLow,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByPriceLow)
        SORT_ELEMENT.verifyLowPriceSort() //Verifing that records are sorted by "Price: Low to High"
    })

    it('Verify the sorting by: ' +pdpSortingValues.sortByPriceHigh,() => {
        SORT_ELEMENT.sortOrderProd(pdpSortingValues.sortByPriceHigh)
        SORT_ELEMENT.verifyHighPriceSort() //Verifing that records are sorted by "Price: High to Low"
    })
})