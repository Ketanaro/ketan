/*
Implementation of PL-32: My Account - Edit section
From this Spec file, we will verify each field by changing the User data.
*/
import { setupEnvAndTestData } from '../support/hooks';
import { accountInfo } from "../pages/actions/myAccountUpdatePage";
import myAccountInfo  from '../fixtures/myAccountInfo.json';
import * as loginPage from '../pages/actions/loginPage';

const My_Account_Update = new accountInfo() //Variable to get the values of Elements for My Profile.

describe('TS: Verify that User are able to Edit the Profile Details',() => {

    setupEnvAndTestData()

    let TESTDATA;  //Load the data from based on the Env.
    beforeEach('',() => {
        cy.visit('/account/sign-in')
        TESTDATA = Cypress.env('testData')  //Load the data based on the Env.
        loginPage.loginToEzContacts(TESTDATA.users.username,TESTDATA.users.password) //Load the data based on the Env.
        My_Account_Update.profileEditLink();
    })

    it('TC: My Account section, Details update', () => {
        //Configure the User Preferences
        My_Account_Update.UserPreferences(myAccountInfo.EditInformation.UserFname,
            myAccountInfo.EditInformation.UserLname,
            myAccountInfo.EditInformation.UserPhNum)

        //Configure the Email Preferences
        My_Account_Update.EmailPreferences(TESTDATA.users.username,
            TESTDATA.users.username)

        //Configure the Password
        My_Account_Update.PasswordSetup(TESTDATA.users.password,
            TESTDATA.users.password,
            TESTDATA.users.password)

        //Verification on the "Save Changes"
        //My_Account_Update.profileSaveBtn()

        // //Verification for "Cancel Link"
        //My_Account_Update.profileEditLink();
        My_Account_Update.profileCancelLink()
    })
})