import { clickOnNoThanksButton } from '../pages/actions/newHomePage';
/**
 * This is hooks file and here we configured before steps which run before all test methods
 * Here loading the env name and its data file and constants file
 * Visit the url in browser as per env. wise
 */
const loadTestData = () => {
    const env = Cypress.env('envName') // Default to 'staging' if no environment is specified
    const fixtureFile = `${env}-test-data.json`; //get the test data file name as per env.
    const constantFile = "constants.json"; //constants file name

     //Loaded test data as per environment
     cy.fixture(fixtureFile).then((testData) =>{
        console.log(testData)
        Cypress.env('testData', testData);
    })

    //Loaded constants data
    cy.fixture(constantFile).then((constants) =>{
        console.log(constants)
        Cypress.env('constants', constants);
    })
};

export const setupEnvAndTestData = () => {
    let env = Cypress.env('envName');
    let baseUrl = Cypress.config('baseUrl')
    Cypress.env('baseUrl', baseUrl)
    before(() => {
        loadTestData();
        cy.log("Base URL:"+Cypress.env('baseUrl'))
        cy.log("Environment:"+env)
        cy.visit(baseUrl)
        clickOnNoThanksButton()
    });
};