// ***********************************************************
// This example support/e2e.js is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import './commands';

// Alternatively you can use CommonJS syntax:
// require('./commands')

/**
 * This is uncaught exception handlled globally
 */
Cypress.on('uncaught:exception', (err, runnable) => {

  // Ignore the JSON parse error
  if (err.message.includes('Unexpected end of JSON input')) {
    // returning false here prevents Cypress from failing the test
    return false;
  }


  //Ignore the null values of the classlist

  if (err.message.includes('Cannot read properties of null (reading \'classList\')')) {
    return false;
  }

  // Return true to let other errors fail the test
  return true;
});

/**
 * This is uncaught exception handlled globally
 */
Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the test
  return false
});