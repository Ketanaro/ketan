// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })


//Reusable Method to select the value from Dropdown.
Cypress.Commands.add('clkToDropdown', (element, sortvalue) => {
  cy.get(element).select(sortvalue, {force: true})
})

/**
* This command will send the text to element
* @param element pass the locator
* @param text pass the text which you want to type
*/
Cypress.Commands.add('typeTextToElement', (element, text) => {
  cy.get(element).type(text)
})

/**
 * This comamnd will click on element
 * @param element pass the locator
 */
Cypress.Commands.add('clickOnElement', (element) => {
  cy.get(element).click({force: true})
})

Cypress.Commands.add('clearTextElement', (element) => {
  cy.get(element).should('be.visible')
  .clear()
})

/**
 * This comamnd will click on element if element is exists else skipped
 * @param selector pass the locator
 */
Cypress.Commands.add('clickIfExists', (selector) => {
  cy.get('body').then($body => {
    if ($body.find(selector, {timeout:10000}).length > 0) {
      cy.get(selector).click();
    } else {
      cy.log(`Element ${selector} not found, skipping click.`);
    }
  });
})

/**
 * This comamnd will till the element is not visible
 * @param element pass the locator
 */
Cypress.Commands.add('waitTillElementIsVisible', (element) => {
  cy.get(element, { timeout: 50000 }).should('be.visible');
})

/**
 * This comamnd will get the css value font size of the element
 * @param element pass the locator
 * @param element pass the expected value
 */
Cypress.Commands.add("verifyCssValueFontSizeOfElement", (element, expectedCssValue) =>{
  cy.get(element)
  .should('have.css', 'font-size', expectedCssValue)
})

/**
 * This comamnd will get the css value color of the element
 * @param element pass the locator
 * @param element pass the expected value
 */
Cypress.Commands.add("verifyCssValueColorOfElement", (element, expectedCssValue) =>{
  cy.get(element)
  .should('have.css', 'color', expectedCssValue)
})

Cypress.Commands.add("getTextOfElement", (element,messageElement) =>{
    return cy.get(element).invoke('text').then((text) => {
    return text;
    })
});

Cypress.Commands.add("getTextOfElementandVerify", (element,messageElement) =>{
  return cy.get(element).then(($input) => {
    expect($input[0].validationMessage).to.eq(messageElement)
  })
});

/**
 * This comamnd will verify the element is visible
 * @param element pass the locator
 */
Cypress.Commands.add('verifyElementShouldBeVisible', (element) => {
  cy.get(element).should('be.visible');
})

/**
 * This comamnd will verify length of element
 * @param element pass the locator
 * @param expectedLength pass the expected length of the elements
 */
Cypress.Commands.add('verifyLengthOfElements', (element, expectedLength) => {
  cy.get(element).should('have.length', expectedLength);
})

/**
 * This command will verify the given text is contains or not in element text
 * @param element pass the locator
 * @param expectedText pass the expected value which you want to verify
 */
Cypress.Commands.add("verifyContainsTextOfElement", (element, expectedText) =>{
  cy.get(element).should('contain',expectedText)
})

/**
* This comamnd will click on element
* @param element pass the locator
*/
Cypress.Commands.add('clickOnElement', (element) => {
cy.get(element).should('be.visible').click()
})

Cypress.Commands.add("clearTextField", (element) =>{
cy.get(element).clear()

});

/**
* This command will help in choosing value from dropdown
* @param element pass the locator
* @value Provide the value to be selected
*/
Cypress.Commands.add("selectValue", (element, value) =>{
cy.get(element)
  .select(value)
})

//This comamnd will verify that element is Enable
Cypress.Commands.add('verifyElementShouldBeEnable', (element) => {
  cy.get(element).should('be.enabled');
})


//Call this function, To verify the New User Registration flow(PL-28,30).
//--------PL-31:Start Here --------
import { registerUser } from "../pages/actions/userRegistration";
// import { faker } from '@faker-js/faker'

// const EZ_USER_REG = new registerUser()

// //Using the Faker Library, We will call this function to generate the Dynamic Data.
// Cypress.Commands.add('generateData',() => {
//   const userData = {
//       signUpFirstName: faker.person.firstName(),  //Generate the First Name.
//       signUpLastName: faker.person.lastName(),  //Generate the Last Name.
//       signUpPassvisible: faker.internet.password(),  //Generate the custom password.
//       signUpEmail: faker.internet.email({provider: 'yopmail.com'}),  //Generate the Email Address.
//       signUpEmailProd: faker.internet.email()  //Use this parameter to get the live Email Address
//   };
//   return userData;
// })

// //--------PL-31: Custom Method to Register the User --------

// Cypress.Commands.add('registerNewUser',() => {
//   cy.generateData().then((userData) =>{
//     EZ_USER_REG.signInEmailInput(userData.signUpEmail) //Replace with 'signUpEmailProd' parameter to run in Prod Env.
//     EZ_USER_REG.modalPopup()
//     EZ_USER_REG.signInConEmailInput(userData.signUpEmail) //Replace with 'signUpEmailProd' parameter to run in Prod Env.
//     EZ_USER_REG.signInFirstNameInput(userData.signUpFirstName)
//     EZ_USER_REG.singInLastNameInput(userData.signUpLastName)
//     EZ_USER_REG.signInPasswordInput('test123')
//     EZ_USER_REG.signInConPasswordInput('test123')
//     EZ_USER_REG.signUpBtn()
//     EZ_USER_REG.signInSuccessMsg()
//   })
// })
//--------PL-31:Ends Here--------