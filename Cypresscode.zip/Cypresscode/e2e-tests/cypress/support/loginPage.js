export let LoginPage = {
    Logo: () => cy.get("img[alt='EzContacts']"),
    ForgotPassword: () => cy.get("#forgot-password-link"),
    ForgotPasswordPopup: () => cy.get(
        'body > div:nth-child(3) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > h4:nth-child(2)'
    ),
    ForgotPasswordPopupClose: () => cy.get(
        '#forgot-password > .modal-dialog > .modal-content > .modal-header > .close > [aria-hidden="true"]'
    ),
    UserEmail: () => cy.get("#UserEmail"),
    UserPassword: () => cy.get("#new-password"),
    SignInButton: () => cy.get("#sign-in-submit-btn"),
    WelcomeLabel: () => cy.get('div[amplitude-id="PageTopWelcomeLabel"]'),
    ErrorMessage: () => cy.get("#authMessage"),
    ResetPasswordPopup: () => cy.get("#reset-password-suggestion > .modal-dialog > .modal-content > .modal-header > #myModalLabel"),
    ResetPasswordPopupClose: () => cy.get('#reset-password-suggestion > .modal-dialog > .modal-content > .modal-header > .close > [aria-hidden="true"]')
}