export const ProductDetails = {
    ProductDetailsPage : {
        addToCartButton: '.add-to-cart-btn-container .btn-cart .add-to-cart-btn',
        frameSize: '.frame_size',
        color:'.select-size .colorSelectoptions',
        successMsgCart: '.content > .container > :nth-child(1)',
        checkoutButton: '.header-right > .btn',


        prescriptionType:'.prescription-type-section .ezMarkLabel',
        rightSphereValue: '#AccountPrescriptionRightSph',
        rightCylinderValue: '#AccountPrescriptionRightCyl',
        rightAxisValue: '#AccountPrescriptionRightAxis',
        leftSphereValue: '#AccountPrescriptionLeftSph',
        leftCylinderValue: '#AccountPrescriptionLeftCyl',
        leftAxisValue: '#AccountPrescriptionLeftAxis',
        pupilDistance: '#AccountPrescriptionPd1',

        selectionErrorMsg:'.selection-error-message + button',
        moveNextToMaterial: '#step3-content > .step-btns > .pull-right',
        materialSelection: '.lens-material label',
        moveNextToCoatings: '#step5-content > .step-btns > .pull-right',
        coatingSelection: '.lense-coating-class',
        moveNextToLensColor: '#step6-content > .step-btns > .pull-right',
        lensColor: '.owl-item h3',
        completeButton: '#complete-btn',

        rightEyePowerValue: '#AppProductRightPower',
        leftEyePowerValue: '#AppProductLeftPower',
        addToCartButtonContactLens: '.btn-cart .add-to-cart-btn',

        samePrescription: '.row > .form-spacer > .clearfix > a',
        samePrescriptionNoOfBoxes: '#same-prescription-how-many',
        rightNoOfBoxes: '#AppProductRightHowMany',
        leftNoOfBoxes: '#AppProductLeftHowMany',
    }
}