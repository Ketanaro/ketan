export const FilterEyeglasses = {
    eyeglassesFilters: {
    GenderMale: '#FilterEyeglassesForm > .gender-filter > :nth-child(1) > .clearfix > a',
    GenderFemale: '#FilterEyeglassesForm > .gender-filter > :nth-child(2) > .clearfix > a',
    GenderChildren: '#FilterEyeglassesForm > .gender-filter > :nth-child(3) > .clearfix > a',

    PriceUnder99: '#FilterEyeglassesForm > .price > :nth-child(1) > .clearfix > a',
    PriceUnder149: '#FilterEyeglassesForm > .price > :nth-child(2) > .clearfix > a',
    PriceUnder199: '#FilterEyeglassesForm > .price > :nth-child(3) > .clearfix > a',
    PriceAbove200: '#FilterEyeglassesForm > .price > :nth-child(4) > .clearfix > a',
    PriceAny: '#FilterEyeglassesForm > .price > :nth-child(5) > .clearfix > a',

    ShapeAviator: '.shapes > :nth-child(1) > .clearfix > a',
    ShapeCatEye: '.shapes > :nth-child(2) > .clearfix > a',
    ShapeOval: '.shapes > :nth-child(3) > .clearfix > a',
    ShapeRectangle: '.shapes > :nth-child(4) > .clearfix > a',
    ShapeRound: '.shapes > :nth-child(5) > .clearfix > a',
    ShapeSquare: '.shapes > :nth-child(6) > .clearfix > a',
    ShapeWayfarer: '.shapes > :nth-child(7) > .clearfix > a',

    FrameTypeRimless: '#FilterEyeglassesForm > .frame-types-filters > :nth-child(1) > .clearfix > a',
    FrametypeSemiRimless: '#FilterEyeglassesForm > .frame-types-filters > :nth-child(2) > .clearfix > a',
    FrameTypeFullFrame: '#FilterEyeglassesForm > .frame-types-filters > :nth-child(3) > .clearfix > a',

    MaterialMetal: '#FilterEyeglassesForm > .materials-filters > :nth-child(3) > .clearfix > a',
    MaterialPlastic: '#FilterEyeglassesForm > .materials-filters > :nth-child(4) > .clearfix > a',

    LensWidth: '#FilterLensWidth',
    BridgeWidth: '#FilterBridgeWidth',
    ArmLength: '#FilterArmLength',

    AnySizeButton: '#FilterEyeglassesForm > .lens-nav-cols > :nth-child(4) > .clearfix > #refine-frame-size-btn',

    ResetFilter: '#reset-all-filter-link',
    }
}

