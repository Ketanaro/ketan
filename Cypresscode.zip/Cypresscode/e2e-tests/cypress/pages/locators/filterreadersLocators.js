export const FilterReaders = {
    readerFilters:  {
    GenderMale: '#FilterReadersForm > .gender-filter > :nth-child(1) > .clearfix > a',
    GenderFemale: '#FilterReadersForm > .gender-filter > :nth-child(2) > .clearfix > a',

    PriceUnder99: '#FilterReadersForm > .price > :nth-child(1) > .clearfix > a',
    PriceUnder149: '#FilterReadersForm > .price > :nth-child(2) > .clearfix > a',
    PriceUnder199: '#FilterReadersForm > .price > :nth-child(3) > .clearfix > a',
    PriceAbove200: '#FilterReadersForm > .price > :nth-child(4) > .clearfix > a',
    PriceAny: '#FilterReadersForm > .price > :nth-child(5) > .clearfix > a',

    ShapeCatEye: '.shapes > :nth-child(2) > .clearfix > a',
    ShapeRectangle: '.shapes > :nth-child(5) > .clearfix > a',

    FrametypeSemiRimless: '#FilterReadersForm > .frame-types-filters > :nth-child(2) > .clearfix > a',
    FrametypeRimless: '#FilterReadersForm > .frame-types-filters > :nth-child(1) > .clearfix > a',
    FrameTypeFullFrame: '#FilterReadersForm > .frame-types-filters > :nth-child(3) > .clearfix > a',

    LensWidth: '#FilterLensWidth',
    BridgeWidth: '#FilterBridgeWidth',
    ArmLength: '#FilterArmLength',

    AnySizeButton: '#FilterReadersForm > .lens-nav-cols > :nth-child(4) > .clearfix > #refine-frame-size-btn',

    ResetFilter: '#reset-all-filter-link',
    }
}