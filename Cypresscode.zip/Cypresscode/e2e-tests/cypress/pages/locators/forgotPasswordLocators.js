//Implementation for PL-29

export const FORGOTPASSWORD = {

    forgotpassword: {
        forgotPasswordLink: '#forgot-password-link',  //Login Page - Forgot Link//'a[data-target="#forgot-password"]',
        forgotEmailInput: '#reset-password-email',  //Forgot Link - Email Address field from popup
        forgotResetBtn: '#send-reset-link-button',  //Forgot Link - Send reset link button
        forgotEmailSentSuccess: 'div.success-msg',  //Login Page - Validation message
        forgotInvalidEmailvalidation:'div#error-message-container',  //Forgot Link - Validation message
        forgotNewUserEmailvalidation: 'div#error-message-container',  //Forgot Link - Validation message
		forgotPassword2MinMessage: 'div#error-message-container'  //Forgot Link - Validation message
    }
}