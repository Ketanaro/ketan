export const ProductBasket = {
    ProductBasketPage :{
        successMsgCart: '.content > .container > :nth-child(1)',
        checkoutButton: '.header-right > .btn',
    }
}