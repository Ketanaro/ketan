//Implementation for PL-28, PL-31

export const newUserRegister = {

userRegister : {
    signInnewCustRadbtn: 'label[for="new-customer"]',  //Registration Page - New User Registration radio button.
    signInEmailInput: '#UserEmail',  //Registration Page - New Email 
    signInConEmailInput: 'input#UserConfirmEmail',  //Registration Page - Confirm Email Input
    signInFirstNameInput: 'input#UserNameFirst',  //Registration Page - User's First Name Input
    singInLastNameInput: 'input#UserNameLast',  //Registration Page - Users;s Last Name Input
    signInPasswordInput: 'input#new-password',  //Registration Page - Password Input
    signInConPasswordInput: 'input#confirm-new-password',   //Registration Page - New Password Input
    signUpBtn: 'input#sign-in-submit-btn',   //Registration Page - Submit button 
    modalPopup: '#jsShowErrorModalCloseButton',    //Registration Page - Email validation popup - Close button
    signInSuccessMsg: 'div.success',   //Registration Page - Success Message
    emailReorderChk: () => cy.get('div.prettycheckbox a').eq(0), //Registration Page - Email Reorder ChkBx
    contactLensChk: () => cy.get('div.prettycheckbox a').eq(1), //Registration Page - Contact Lens CheBx
    eyeglassPromoChk: () => cy.get('div.prettycheckbox a').eq(2),  //Registration Page - Eyeglasses Promotion Chkbox
    sunglassPromoChk: () => cy.get('div.prettycheckbox a').eq(3), //Registration Page - Sunglasses promotion chkbox
    rememberMeChk: () => cy.get('div.prettycheckbox a').eq(4), //Registration Page - Remember Me Chkbox
}
}