export const LOCATORS = {
    newHomePage:{
        noThanksBtnPopup : "div.ltkpopup-no-thanks button",
        titleTxtWhyChooseEZ : "div.whychoose-container div[class*='header-text'] span",
        titleTextWhatTheySayAbout : "h4.about-us-title",
        titleTextFAQs : "div.faq-list h4.title",
        imgFAQs: "section.faq-section figure.image img",
        viewAllBtnFAQs: "section.faq-section a.link",
        FAQsList: "section[class='faq-section'] ul[class='accordion-list']>li",
        imgTestVisionBanner: "img[alt*='Your Vision?']",
        imgVirtualTryOnBanner: "img[alt='Virtually Try-On Glasses']"
    },

    faqPage:{
        titleAllFAQs : "div.section>h2.section-title",
        helpLauncher : "span[data-testid='launcher-label']",
        listOfFAQs   : 'div[class="panel panel-faq"] a'
    }
};