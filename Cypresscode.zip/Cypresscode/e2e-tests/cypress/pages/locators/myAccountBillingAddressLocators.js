export const myAccountBillingFlow = {
    myAccountBillingPage : {
        addBillingAddress : "a[href='/account/address-and-payment/add-billing-address']",
        internationalBillingAddress : '.has-pretty-child > :nth-child(2) > a',
        countryBilling : '#AccountBillingAddressAddressCountry',
        firstNameBilling : '#AccountBillingAddressFirstName',
        lastNameBilling : '#AccountBillingAddressLastName',
        companyNameBilling : '#AccountBillingAddressAddressBillCompany',
        companyAddress1Billing : '#AccountBillingAddressAddressLine1',
        companyAddress2Billing : '#AccountBillingAddressAddressLine2',
        cityBilling : '#AccountBillingAddressAddressCity',
        stateBilling : '#AccountBillingAddressUsAddressRegion',
        internationalStateBilling : '#AccountBillingAddressAddressRegion',
        pincodeBilling : '#AccountBillingAddressAddressPostalZip',
        phoneNumberBilling : '#AccountBillingAddressAddressBillPhonePrimary',
        saveButtonBilling : '#account_add_bill_btn',
        firstNameErrorBilling : '#AccountBillingAddressFirstName-error',
        lastNameErrorBilling : '#AccountBillingAddressLastName-error',
        companyAddress1ErrorBilling : '#AccountBillingAddressAddressLine1-error',
        cityErrorBilling : '#AccountBillingAddressAddressCity-error',
        pincodeErrorBilling : '#AccountBillingAddressAddressPostalZip-error',
        phoneNumberErrorBilling : '#AccountBillingAddressAddressBillPhonePrimary-error',
    }
}