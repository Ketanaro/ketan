export const LOCATORS = {
    login: {
        loginPageLogo: "img[alt='EzContacts']",   //Login Page - Logo from Login Page.
        returningCustomer: 'label[for="old-customer"]',  //Login Page - Returning Customer Radio button.
        loginLnk: "[amplitude-id='PageTopLoginLink']",  // Home Page - Login Link from header.
        username: "#UserEmail", //Login Page - Username
        password: "#new-password", //Login Page - Password
        signInBtn: "#sign-in-submit-btn",  //Login Page - Sign In button
        successMsg: "[class='message success success-msg']",   //Success Message - after successfully Login
        invalidCredMsg: "#authMessage",  //Invalid credintial message
        noThanksBtnPopup : "div.ltkpopup-no-thanks button"
    }
}