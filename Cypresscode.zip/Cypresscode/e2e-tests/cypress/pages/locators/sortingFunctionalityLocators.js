export const sortingFunctionality = {
    sortingElement: {
        sunglassSorting:'#products-sort-order-select', //'select#products-sort-order-select', //sorting dropdown element - Staging
        prodSorting: 'div.unbxd-sort-container select', //sorting dropdown element - Production
        sortingReaderValue: 'select#products-sort-order-select' //sorting dropdown element - Production
    }
}