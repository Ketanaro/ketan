export const FilterSunglasses = {
    sunglassesFilters: {
    GenderMale: '#FilterSunglassesForm > .gender-filter > :nth-child(1) > .clearfix > a',
    GenderFemale: '#FilterSunglassesForm > .gender-filter > :nth-child(2) > .clearfix > a',
    GenderChildren: '#FilterSunglassesForm > .gender-filter > :nth-child(3) > .clearfix > a',

    CategoryClearance: '#FilterSunglassesForm > .categories-filter > :nth-child(1) > .clearfix > a',
    CategoryPrescriptionCapable: '#FilterSunglassesForm > .categories-filter > :nth-child(2) > .clearfix > a',

    PriceUnder99: '#FilterSunglassesForm > .price > :nth-child(1) > .clearfix > a',
    PriceUnder149: '#FilterSunglassesForm > .price > :nth-child(2) > .clearfix > a',
    PriceUnder199: '#FilterSunglassesForm > .price > :nth-child(3) > .clearfix > a',
    PriceAbove200: '#FilterSunglassesForm > .price > :nth-child(4) > .clearfix > a',
    PriceAny: '#FilterSunglassesForm > .price > :nth-child(5) > .clearfix > a',

    ShapeAviator: '.shapes > :nth-child(1) > .clearfix > a',
    ShapeCatEye: '.shapes > :nth-child(2) > .clearfix > a',
    ShapeOval: '.shapes > :nth-child(3) > .clearfix > a',
    ShapeRectangle: '.shapes > :nth-child(4) > .clearfix > a',
    ShapeRound: '.shapes > :nth-child(5) > .clearfix > a',
    ShapeSquare: '.shapes > :nth-child(6) > .clearfix > a',

    FrameTypeRimless: '#FilterSunglassesForm > .frame-types-filters > :nth-child(1) > .clearfix > a',
    FrameTypeFullFrame: '#FilterSunglassesForm > .frame-types-filters > :nth-child(3) > .clearfix > a',

    MaterialPlastic: '#FilterSunglassesForm > .materials-filters > :nth-child(4) > .clearfix > a',

    LensWidth: '#FilterLensWidth',
    BridgeWidth: '#FilterBridgeWidth',
    ArmLength: '#FilterArmLength',

    AnySizeButton: '#FilterSunglassesForm > .lens-nav-cols > :nth-child(4) > .clearfix > #refine-frame-size-btn',

    ResetFilter: '#reset-all-filter-link',
    }
}