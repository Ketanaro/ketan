export const profileUpdate = { 

    MyAccountElement:{
        profileEditLink: 'a[href="/account/settings/edit"]', //Edit Details Link.
        profileFName: 'input#UserNameFirst', //Edit Account - First Name.
        profileLName: 'input#UserNameLast', //Edit Account - LastName .
        profilePhNum: 'input#AccountContactPhoneNumber', //Edit Account - PhoneNumber .
        profileNewEmail: 'input#UserEmail', //Edit Account - Enter New Email.
        profileConfirmEmail: 'input#UserConfirmEmail', //Edit Account - Enter Confirm Email.
        profileOldPass: 'input#UserOldPassword', //Edit Account - Old Password.
        profileNewPass: 'input#UserPassword', //Edit Account - New Password.
        profileConfirmPass: 'input#UserTemppassword', //Edit Account - Confirm Password.
        profilePassEyeIcon: "('span.eye-icon').eq(0)", //Edit Account - Password Eye Icon.
        profileSaveBtn: 'input[type="submit"]', //Edit Account - Save Changes.
        profileCancelLink: '.cancel', //'div.submit-box div', // Edit Account - Cancel Link.
        profileValidationSuccess: 'div.success-msg', //Edit Account - Save button - Success Msg.
        profileOldPassValidation: '.error-message', //Edit Account - Old Pwd Blank - Validation message(Password did not match with your existing one.)
        profilePasswordMismatch: '#UserTemppassword-error', //Edit Account - Diff. New and Confirm Pass - Validation message(Please enter the same password as above)
        profileInvalidPassSetup:'#UserTemppassword-error', //Edit Account - add 2-3 alphanumberic for New and Confirm Pass - Validation message(Your password must be at least 6 characters long)
        ProfileNewEmailAlert: ':nth-child(3) > .col-md-5 > .error-message', //Edit Account - Email Preferences
        ProfileConfrimEmailAlert: '#UserConfirmEmail-error', //Edit Account - Email Preferences
        ProfileSingleEmailAlert: ':nth-child(4) > .col-md-5 > .error-message', //Edit Account - Email Preferences
    }
}