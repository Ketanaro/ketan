import { myAccountBillingFlow } from "../locators/myAccountBillingAddressLocators";
import { LOCATORS } from "../locators/newHomePageLocators";

export function clickOnNoThanksButton() {
  cy.clickIfExists(LOCATORS.newHomePage.noThanksBtnPopup);
}

export function addBillingAddress() {
  cy.clickOnElement(
    myAccountBillingFlow.myAccountBillingPage.addBillingAddress
  );
}

export function internationalBillingAddress() {
  cy.clickOnElement(
    myAccountBillingFlow.myAccountBillingPage.internationalBillingAddress
  );
}

export function countryBilling() {
  cy.selectValue(
    myAccountBillingFlow.myAccountBillingPage.countryBilling,
    "India"
  );
}

export function firstNameBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.firstNameBilling,
    "KaranUser1"
  );
}

export function lastNameBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.lastNameBilling,
    "SharmaUser1"
  );
}

export function companyNameBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.companyNameBilling,
    "EZ1"
  );
}

export function companyAddress1Billing() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.companyAddress1Billing,
    "2 Bergen TPKE"
  );
}

export function cityBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.cityBilling,
    "Suit 104"
  );
}

export function stateBilling() {
  cy.selectValue(
    myAccountBillingFlow.myAccountBillingPage.stateBilling,
    "Ohio"
  );
}

export function internationalStateBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.internationalStateBilling,
    "Delhi"
  );
}

export function pincodeBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.pincodeBilling,
    "12345"
  );
}

export function phoneNumberBilling() {
  cy.typeTextToElement(
    myAccountBillingFlow.myAccountBillingPage.phoneNumberBilling,
    "56789123"
  );
}

export function saveButtonBilling() {
  cy.clickOnElement(
    myAccountBillingFlow.myAccountBillingPage.saveButtonBilling
  );
}

export function firstNameErrorBilling() {
  cy.verifyElementShouldBeVisible(
    myAccountBillingFlow.myAccountBillingPage.firstNameErrorBilling
  );
}

export function lastNameErrorBilling() {
  cy.verifyElementShouldBeVisible(
    myAccountBillingFlow.myAccountBillingPage.lastNameErrorBilling
  );
}

export function companyAddress1ErrorBilling() {
  cy.verifyElementShouldBeVisible(
    myAccountBillingFlow.myAccountBillingPage.companyAddress1ErrorBilling
  );
}

export function cityErrorBilling() {
  cy.verifyElementShouldBeVisible(
    myAccountBillingFlow.myAccountBillingPage.cityErrorBilling
  );
}

export function pincodeErrorBilling() {
  cy.verifyElementShouldBeVisible(
    myAccountBillingFlow.myAccountBillingPage.pincodeErrorBilling
  );
}

export function phoneNumberErrorBilling() {
  cy.verifyElementShouldBeVisible(
    myAccountBillingFlow.myAccountBillingPage.phoneNumberErrorBilling
  );
}