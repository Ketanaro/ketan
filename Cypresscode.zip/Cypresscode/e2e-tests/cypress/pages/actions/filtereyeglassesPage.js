import { FilterEyeglasses } from "../locators/filtereyeglassesLocators";

export class eyeglassFilterFunction{
    navigateToEyeglasses() {
        cy.get('.dropdown [href="/eyeglasses"]').should('contain.text','EYEGLASSES').click()
        cy.url().should('include','/eyeglasses') //validate URL
        return this;
    }

    GenderMale(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.GenderMale);
    }

    GenderFemale(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.GenderFemale)
    }

    GenderChildren(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.GenderChildren)
    }

    PriceUnder99(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.PriceUnder99)
    }

    PriceUnder149(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.PriceUnder149)
    }

    PriceUnder199(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.PriceUnder199)
    }

    PriceAbove200(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.PriceAbove200)
    }

    PriceAny(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.PriceAny)
    }

    ShapeAviator(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeAviator)
    }

    ShapeCatEye(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeCatEye)
    }

    ShapeOval(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeOval)
    }

    ShapeRectangle(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeRectangle)
    }

    ShapeRound(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeRound)
    }

    ShapeSquare(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeSquare)
    }

    ShapeWayfarer(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ShapeWayfarer)
    }

    FrameTypeFullFrame(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.FrameTypeFullFrame)
    }

    FrameTypeRimless(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.FrameTypeRimless)
    }

    FrametypeSemiRimless(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.FrametypeSemiRimless)
    }

    MaterialMetal(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.MaterialMetal)
    }

    MaterialPlastic(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.MaterialPlastic)
    }

    LensWidth(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.LensWidth)
    }

    BridgeWidth(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.BridgeWidth)
    }

    ArmLength(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ArmLength)
    }

    AnySizeButton(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.AnySizeButton)
    }

    ResetFilter(){
        return cy.verifyElementShouldBeVisible(FilterEyeglasses.eyeglassesFilters.ResetFilter)
    }
}