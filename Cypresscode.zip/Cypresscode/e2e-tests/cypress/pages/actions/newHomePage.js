import { LOCATORS } from "../../pages/locators/newHomePageLocators";

export function clickOnNoThanksButton(){
    cy.clickIfExists(LOCATORS.newHomePage.noThanksBtnPopup)
}

export function verifyMainImageIsVisible(){
    cy.verifyElementShouldBeVisible(LOCATORS.newHomePage.imgFAQs)
}

export function clickOnViewAllButton(){
    cy.get(LOCATORS.newHomePage.viewAllBtnFAQs).click()
}

export function verifyFAQsLength(expectedLength) {
    cy.verifyLengthOfElements(LOCATORS.newHomePage.FAQsList, expectedLength)
}

export function clickOnFAQsQuestionsBySequnceNumber(number) {
    cy.get(LOCATORS.newHomePage.FAQsList)
    .eq(number)
    .click()
}

export function verifyFAQsShouldBeOpenedBySequenceNumber(number){
    cy.get(LOCATORS.newHomePage.FAQsList)
    .eq(number)
    .should('have.attr', 'class', 'active');
}

export function verifyFAQsShouldBeClosedBySequenceNumber(number){
    cy.get(LOCATORS.newHomePage.FAQsList)
    .eq(number)
    .invoke('attr', 'class')
    .then((classValue) => {
      expect(classValue).to.be.oneOf([undefined, '']);
    });
}

export function verifyLisOfFAQsAreVisible(){
    cy.verifyElementShouldBeVisible(LOCATORS.faqPage.listOfFAQs)
}

export function verifyUrlInclude(path){
    cy.url()
    .should('include', path);
}

export function verifyFAQTitleFontSize(fontsize){
    cy.verifyCssValueFontSizeOfElement(LOCATORS.newHomePage.titleTextFAQs, fontsize)
}

export function verifyFAQTitleFontColor(color){
    cy.verifyCssValueColorOfElement(LOCATORS.newHomePage.titleTextFAQs, color)
}

export function verifyViewAllButtonFontSize(fontsize){
    cy.verifyCssValueFontSizeOfElement(LOCATORS.newHomePage.viewAllBtnFAQs, fontsize)
}

export function verifyViewAllButtonColor(color){
    cy.verifyCssValueColorOfElement(LOCATORS.newHomePage.viewAllBtnFAQs, color)
}

export function verifyTitleTextOfFAQs(expectedValue){
    verifyTextOfElement(LOCATORS.newHomePage.titleTextFAQs, expectedValue)
}

export function verifyTextOfViewAllButton(expectedValue){
    verifyTextOfElement(LOCATORS.newHomePage.viewAllBtnFAQs, expectedValue)
}

function verifyTextOfElement(element, value){
    cy.getTextOfElement(element).then((text) => {
        cy.log('Actual Text is:', text); 
        expect(text).to.equal(value); 
    });
}

export function verifyTestVisionBannerIsVisible(){
    cy.verifyElementShouldBeVisible(LOCATORS.newHomePage.imgTestVisionBanner)
}

export function clickOnTestVisionBanner(){
    cy.clickOnElement(LOCATORS.newHomePage.imgTestVisionBanner)
}

export function verifyVirtualTryOnBannerIsVisible(){
    cy.verifyElementShouldBeVisible(LOCATORS.newHomePage.imgVirtualTryOnBanner)
}

export function clickOnVirtualTryOnBanner(){
    cy.clickOnElement(LOCATORS.newHomePage.imgVirtualTryOnBanner)
}