import { ProductBasket } from "../locators/ProductBasketPageLocators";

export class ProductBasketElements{
    successMsgCart(AddToCartSuccessfully){
        return cy.get(ProductBasket.ProductBasketPage.successMsgCart)
                .should("be.visible")
                .should("have.text",AddToCartSuccessfully)
    }

    checkoutButton(){
        return cy.get(ProductBasket.ProductBasketPage.checkoutButton)
    }
}