//Implementation for PL-29
import { FORGOTPASSWORD } from '../locators/forgotPasswordLocators'

    export function forgotPasswordLink(){
        cy.clickOnElement(FORGOTPASSWORD.forgotpassword.forgotPasswordLink)
    }

    export function forgotTypeEmail(email){
        cy.get('#reset-password-email').should('be.enabled')
        .click()
        .type(email, {force: true})
    }
    export function forgotEmailInput(email){
        cy.clearTextField(FORGOTPASSWORD.forgotpassword.forgotEmailInput)
        cy.typeTextToElement(FORGOTPASSWORD.forgotpassword.forgotEmailInput,email)
        cy.clearTextField(FORGOTPASSWORD.forgotpassword.forgotEmailInput)
        cy.typeTextToElement(FORGOTPASSWORD.forgotpassword.forgotEmailInput,email)
    }

    export function forgotResetBtn(){
        cy.verifyElementShouldBeEnable(FORGOTPASSWORD.forgotpassword.forgotResetBtn)
        cy.clickOnElement(FORGOTPASSWORD.forgotpassword.forgotResetBtn)
    }

    export function forgotEmailSentSuccess(validEmailMessage){
        cy.verifyContainsTextOfElement(FORGOTPASSWORD.forgotpassword.forgotEmailSentSuccess,validEmailMessage)
    }

    export function forgotInvalidEmailvalidation(invalidEmailMessage){
        cy.verifyElementShouldBeVisible(FORGOTPASSWORD.forgotpassword.forgotInvalidEmailvalidation)
        cy.verifyContainsTextOfElement(FORGOTPASSWORD.forgotpassword.forgotInvalidEmailvalidation,invalidEmailMessage)
    }

    export function forgotNewUserEmailvalidation(newUserEmailMessage){
        cy.verifyElementShouldBeVisible(FORGOTPASSWORD.forgotpassword.forgotNewUserEmailvalidation)
        cy.verifyContainsTextOfElement(FORGOTPASSWORD.forgotpassword.forgotNewUserEmailvalidation,newUserEmailMessage)
    }

	export function forgotPassword2MinMessage(forgot2MinMsg){
        cy.verifyElementShouldBeVisible(FORGOTPASSWORD.forgotpassword.forgotNewUserEmailvalidation)
        cy.verifyContainsTextOfElement(FORGOTPASSWORD.forgotpassword.forgotPassword2MinMessage,forgot2MinMsg)
    }