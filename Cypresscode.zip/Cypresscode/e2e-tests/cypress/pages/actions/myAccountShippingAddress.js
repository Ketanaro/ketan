import { myAccountAddressFlow } from "../locators/myAccountShippingPageLocators";
import { LOCATORS } from "../locators/newHomePageLocators";

export function clickOnNoThanksButton() {
  cy.clickIfExists(LOCATORS.newHomePage.noThanksBtnPopup);
}

export function addShippingAddress() {
  cy.clickOnElement(myAccountAddressFlow.myAccountPage.addShippingAddress);
}

export function internationalAddress() {
  cy.clickOnElement(myAccountAddressFlow.myAccountPage.internationalAddress);
}

export function country() {
  cy.selectValue(myAccountAddressFlow.myAccountPage.country, "Mexico");
}

export function firstName() {
  cy.typeTextToElement(
    myAccountAddressFlow.myAccountPage.firstName,
    "KaranUser1"
  );
}

export function lastName() {
  cy.typeTextToElement(
    myAccountAddressFlow.myAccountPage.lastName,
    "SharmaUser1"
  );
}

export function addCompanyButton() {
  cy.clickOnElement(myAccountAddressFlow.myAccountPage.addCompanyButton);
}

export function companyName() {
  cy.typeTextToElement(myAccountAddressFlow.myAccountPage.companyName, "EZ1");
}

export function companyAddress1() {
  cy.typeTextToElement(
    myAccountAddressFlow.myAccountPage.companyAddress1,
    "2 Bergen TPKE"
  );
}

export function city() {
  cy.typeTextToElement(myAccountAddressFlow.myAccountPage.city, "Suit 104");
}

export function state() {
  cy.selectValue(myAccountAddressFlow.myAccountPage.state, "New Jersey");
}

export function internationalState() {
  cy.typeTextToElement(
    myAccountAddressFlow.myAccountPage.internationalState,
    "Mexico City"
  );
}

export function pincode() {
  cy.typeTextToElement(myAccountAddressFlow.myAccountPage.pincode, "12345");
}

export function phoneNumber() {
  cy.typeTextToElement(
    myAccountAddressFlow.myAccountPage.phoneNumber,
    "56789123"
  );
}

export function submitButton() {
  cy.clickOnElement(myAccountAddressFlow.myAccountPage.submitButton);
}

export function errorModal() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.errorModal
  );
}

export function thanksButton() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.thanksButton
  ).clickOnElement(myAccountAddressFlow.myAccountPage.thanksButton);
}

export function firstNameError() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.firstNameError
  );
}

export function lastNameError() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.lastNameError
  );
}

export function companyAddress1Error() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.companyAddress1Error
  );
}

export function cityError() {
  cy.verifyElementShouldBeVisible(myAccountAddressFlow.myAccountPage.cityError);
}

export function pincodeError() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.pincodeError
  );
}

export function phoneNumberError() {
  cy.verifyElementShouldBeVisible(
    myAccountAddressFlow.myAccountPage.phoneNumberError
  );
}