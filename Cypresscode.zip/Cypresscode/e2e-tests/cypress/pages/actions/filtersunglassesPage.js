import { FilterSunglasses } from "../locators/filterssunglassesLocators"

export class filterSunglasses{
    navigateToSunglasses(){
        cy.get('.dropdown [href="/sunglasses"]').should('contain.text','SUNGLASSES').click() //SUNGLASSES menu
        cy.url().should('include','/sunglasses') //Validate URL
    }

    GenderMale(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.GenderMale)
    }

    GenderFemale(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.GenderFemale)
    }

    GenderChildren(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.GenderChildren)
    }

    CategoryClearance(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.CategoryClearance)
    }

    CategoryPrescriptionCapable(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.CategoryPrescriptionCapable)
    }

    PriceUnder99(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.PriceUnder99)
    }

    PriceUnder149(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.PriceUnder149)
    }

    PriceUnder199(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.PriceUnder199)
    }

    PriceAbove200(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.PriceAbove200)
    }

    PriceAny(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.PriceAny)
    }

    ShapeAviator(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ShapeAviator)
    }

    ShapeCatEye(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ShapeCatEye)
    }

    ShapeOval(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ShapeOval)
    }

    ShapeRectangle(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ShapeRectangle)
    }

    ShapeRound(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ShapeRound)
    }

    ShapeSquare(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ShapeSquare)
    }

    FrameTypeFullFrame(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.FrameTypeFullFrame)
    }

    FrameTypeRimless(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.FrameTypeRimless)
    }

    MaterialPlastic(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.MaterialPlastic)
    }

    LensWidth(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.LensWidth)
    }

    BridgeWidth(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.BridgeWidth)
    }

    ArmLength(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ArmLength)
    }

    AnySizeButton(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.AnySizeButton)
    }

    ResetFilter(){
        return cy.verifyElementShouldBeVisible(FilterSunglasses.sunglassesFilters.ResetFilter)
    }
}