//Implementation for PL-28, PL-31
import { newUserRegister } from "../locators/userRegistrationLocator"

export class registerUser{

signInnewCustRadbtn(){
    cy.get(newUserRegister.userRegister.signInnewCustRadbtn).should('be.visible')
    .click()
}

signInEmailInput(rEmail){
    cy.clearTextElement(newUserRegister.userRegister.signInEmailInput)
    cy.get(newUserRegister.userRegister.signInEmailInput)
    .type(rEmail, {log:false})
    cy.get(newUserRegister.userRegister.signInConEmailInput)
    .click()
}
signInConEmailInput(rConfirmEmail){
    cy.clearTextElement(newUserRegister.userRegister.signInConEmailInput)
    cy.get(newUserRegister.userRegister.signInConEmailInput)
    .type(rConfirmEmail,{log:false})
}
signInFirstNameInput(rFirstName){
    cy.clearTextElement(newUserRegister.userRegister.signInFirstNameInput)
    cy.typeTextToElement(newUserRegister.userRegister.signInFirstNameInput,rFirstName)
}
singInLastNameInput(rLastName){
    cy.clearTextElement(newUserRegister.userRegister.singInLastNameInput)
    cy.typeTextToElement(newUserRegister.userRegister.singInLastNameInput,rLastName)
}
signInPasswordInput(rPassword){
    cy.clearTextElement(newUserRegister.userRegister.signInPasswordInput)
    cy.typeTextToElement(newUserRegister.userRegister.signInPasswordInput,rPassword,{log:false})
}
signInConPasswordInput(rConfirmPassword){
    cy.clearTextElement(newUserRegister.userRegister.signInConPasswordInput)
    cy.typeTextToElement(newUserRegister.userRegister.signInConPasswordInput,rConfirmPassword,{log:false})
}
signUpBtn(){
    cy.get(newUserRegister.userRegister.signUpBtn).click()
}
modalPopup(){
    cy.get(newUserRegister.userRegister.modalPopup).click({force:true})
}
verifyChkPropeties(){
    cy.clickOnElement(newUserRegister.userRegister.emailReorderChk)
    cy.contains('label', 'Email Re-Order Reminders').should('not.be.checked')
    .and('have.text','Email Re-Order Reminders')

    cy.clickOnElement(newUserRegister.userRegister.contactLensChk)
    cy.contains('label', 'Contact Lens Promotions')
    .should('not.be.checked')
    .and('have.text','Contact Lens Promotions')

    cy.clickOnElement(newUserRegister.userRegister.eyeglassPromoChk)
    cy.contains('label', 'Eyeglasses Promotions').should('not.be.checked')
    .and('have.text','Eyeglasses Promotions')

    cy.clickOnElement(newUserRegister.userRegister.sunglassPromoChk)
    cy.contains('label', 'Sunglasses Promotions').should('not.be.checked')
    .and('have.text','Sunglasses Promotions')

    cy.clickOnElement(newUserRegister.userRegister.rememberMeChk)
    cy.contains('label','Remember me').should('not.be.checked')
    .and('have.text','Remember me')
}
regPasswordVisibility(rPassword){
    cy.typeTextToElement(newUserRegister.userRegister.signInPasswordInput,rPassword,{log:false})
    cy.get('span[title="Show Password"]').eq(0)
    .click()
}
regConPasswordVisibility(rConfirmPassword){
    cy.typeTextToElement(newUserRegister.userRegister.signInConPasswordInput,rConfirmPassword,{log:false})
    cy.get('div.input span').click()
}
signInSuccessMsg(){
    cy.get(newUserRegister.userRegister.signInSuccessMsg)
    .should('contain.text','Welcome to your new EZContacts.com Account.')
    .and('exist')
}
}