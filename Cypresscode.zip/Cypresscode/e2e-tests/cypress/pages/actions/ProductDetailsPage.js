import { ProductDetails } from "../locators/ProductDetailsPageLocators";
export class ProductDetailsElements{
    addToCartButton(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.addToCartButton)
    }

    frameSize(){
        return cy.get(ProductDetails.ProductDetailsPage.frameSize)
    }

    color(){
        return cy.get(ProductDetails.ProductDetailsPage.color)
    }

    successMsgCart(){
        return cy.get(ProductDetails.ProductDetailsPage.successMsgCart)
    }

    checkoutButton(){
        return cy.get(ProductDetails.ProductDetailsPage.checkoutButton)
    }

    noOfBoxes(boxes){
        return cy.get(ProductDetails.ProductDetailsPage.noOfBoxes)
    }

    prescriptionType(){
        return cy.get(ProductDetails.ProductDetailsPage.prescriptionType)
    }

    samePrescription(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.samePrescription)
    }

    rightSphereValue(){
        return cy.get(ProductDetails.ProductDetailsPage.rightSphereValue)
    }

    rightCylinderValue(){
        return cy.get(ProductDetails.ProductDetailsPage.rightCylinderValue)
    }

    rightAxisValue(){
        return cy.get(ProductDetails.ProductDetailsPage.rightAxisValue)
    }

    leftSphereValue(){
        return cy.get(ProductDetails.ProductDetailsPage.leftSphereValue)
    }

    leftCylinderValue(){
        return cy.get(ProductDetails.ProductDetailsPage.leftCylinderValue)
    }

    leftAxisValue(){
        return cy.get(ProductDetails.ProductDetailsPage.leftAxisValue)
    }

    pupilDistance(){
        return cy.get(ProductDetails.ProductDetailsPage.pupilDistance)
    }

    selectionErrorMsg(){
        return cy.get(ProductDetails.ProductDetailsPage.selectionErrorMsg)
    }
    moveNextToMaterial(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.moveNextToMaterial)
    }
    materialSelection(lensMaterial){
        return cy.get(ProductDetails.ProductDetailsPage.materialSelection)
                 .contains(lensMaterial)
                 .click()
    }

    moveNextToCoatings(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.moveNextToCoatings)
    }

    coatingSelection(antiReflectiveCoating){
        return cy.get(ProductDetails.ProductDetailsPage.coatingSelection)
                 .contains(antiReflectiveCoating)
                 .click()
    }

    moveNextToLensColor(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.moveNextToLensColor)
    }

    lensColor(lensColor){
        return cy.get(ProductDetails.ProductDetailsPage.lensColor)
                 .contains(lensColor)
                .click()
    }

    completeButton(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.completeButton)
    }

    rightEyePowerValue(){
        return cy.get(ProductDetails.ProductDetailsPage.rightEyePowerValue)
    }

    leftEyePowerValue(){
        return cy.get(ProductDetails.ProductDetailsPage.leftEyePowerValue)
    }

    addToCartButtonContactLens(){
        return cy.clickOnElement(ProductDetails.ProductDetailsPage.addToCartButtonContactLens)
    }

    selectFrameAndColor(frame_size,color){
        return cy.selectValue(ProductDetails.ProductDetailsPage.frameSize,frame_size)
                 .selectValue(ProductDetails.ProductDetailsPage.color,color)
    }

    selectPrescriptionType(lensType){
        return cy.get(ProductDetails.ProductDetailsPage.prescriptionType)
                 .contains(lensType)
                 .click()
    }

    selectRightEyeDetails(rightSphereValue, rightCylinderValue, rightAxisValue){
        return cy.selectValue(ProductDetails.ProductDetailsPage.rightSphereValue,rightSphereValue)
                 .selectValue(ProductDetails.ProductDetailsPage.rightCylinderValue,rightCylinderValue)
                 .selectValue(ProductDetails.ProductDetailsPage.rightAxisValue,rightAxisValue)
    }

    selectLeftEyeDetails(leftSphereValue, leftCylinderValue, leftAxisValue){
        return cy.selectValue(ProductDetails.ProductDetailsPage.leftSphereValue,leftSphereValue)
                 .selectValue(ProductDetails.ProductDetailsPage.leftCylinderValue,leftCylinderValue)
                 .selectValue(ProductDetails.ProductDetailsPage.leftAxisValue,leftAxisValue)
    }

    selectPupil_Material_Coating_Color(pDpupilDistance){
        return cy.selectValue(ProductDetails.ProductDetailsPage.pupilDistance,pDpupilDistance)
    }

    selectContactLensDetails(rightEyePower, leftEyePower){
        return cy.selectValue(ProductDetails.ProductDetailsPage.rightEyePowerValue,rightEyePower)
                 .selectValue(ProductDetails.ProductDetailsPage.leftEyePowerValue,leftEyePower)
    }

    selectContactsBoxes(rightBoxes,leftBoxes){
        return cy.selectValue(ProductDetails.ProductDetailsPage.rightNoOfBoxes,rightBoxes)
                 .selectValue(ProductDetails.ProductDetailsPage.leftNoOfBoxes,leftBoxes)
    }

    selectSameContactBoxes(sameBoxes){
        return cy.selectValue(ProductDetails.ProductDetailsPage.samePrescriptionNoOfBoxes,sameBoxes)
    }
}