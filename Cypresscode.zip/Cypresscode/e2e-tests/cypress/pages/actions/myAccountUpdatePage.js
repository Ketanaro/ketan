import { profileUpdate } from "../locators/myAccountUpdateLocator"

export class accountInfo{
    
    UserPreferences(FirstName, LastName, PhoneNumber){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileFName)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileFName,FirstName)

        cy.clearTextElement(profileUpdate.MyAccountElement.profileLName)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileLName,LastName)
        
        cy.clearTextElement(profileUpdate.MyAccountElement.profilePhNum)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profilePhNum,PhoneNumber)
    }

    EmailPreferences(newEmail,confirmEmail){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileNewEmail)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileNewEmail,newEmail) //Edit Account - Enter New Email.
        
        cy.clearTextElement(profileUpdate.MyAccountElement.profileConfirmEmail)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileConfirmEmail,confirmEmail) //Edit Account - Enter Confirm Email.
    }
    
    PasswordSetup(OldPassword, NewPassword, NewConfPass){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileOldPass)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileOldPass,OldPassword) //Edit Account - Set the Old Password.

        cy.clearTextElement(profileUpdate.MyAccountElement.profileNewPass)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileNewPass,NewPassword)

        cy.clearTextElement(profileUpdate.MyAccountElement.profileConfirmPass)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileConfirmPass,NewConfPass)
    }
    
    profileEditLink(){
        cy.get(profileUpdate.MyAccountElement.profileEditLink)
        .should('contain','Edit details')
        cy.clickOnElement(profileUpdate.MyAccountElement.profileEditLink) //Clicking on the "Edit Details" Link
        return this;
    }
    
    profileFName(FName){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileFName)
        cy.get(profileUpdate.MyAccountElement.profileFName)
        .type(FName) //Edit Account - Set the First Name.
        return this;
    }

    profileLName(lastName){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileLName)
        cy.get(profileUpdate.MyAccountElement.profileLName)
        .type(lastName) //Edit Account - Set the LastName.
        return this;
    }

    profilePhNum(PhNumber){
        cy.clearTextElement(profileUpdate.MyAccountElement.profilePhNum)
        cy.get(profileUpdate.MyAccountElement.profilePhNum)
        .type(PhNumber) //Edit Account - Set the PhoneNumber.
        return this;
    }

    profileNewEmail(NewEmail){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileNewEmail)
        cy.get(profileUpdate.MyAccountElement.profileNewEmail)
        .type(NewEmail) //Edit Account - Enter New Email.
        return this;
    }

    profileConfirmEmail(confirmEmail){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileConfirmEmail)
        cy.get(profileUpdate.MyAccountElement.profileConfirmEmail)
        .type(confirmEmail) //Edit Account - Enter Confirm Email.
        return this;
    }
    profileOldPass(OldPass){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileOldPass)
        cy.get(profileUpdate.MyAccountElement.profileOldPass)
        .type(OldPass) //Edit Account - Set the Old Password.
        return this;
    }
    
    profileNewPass(NewPassword){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileNewPass)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileNewPass,NewPassword)
        return this;
    }

    profileConfirmPass(NewConfPass){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileConfirmPass)
        cy.typeTextToElement(profileUpdate.MyAccountElement.profileConfirmPass,NewConfPass)
        return this;
    }

    profileSaveBtn(){
        cy.get(profileUpdate.MyAccountElement.profileSaveBtn)
        .should('be.enabled')
        cy.clickOnElement(profileUpdate.MyAccountElement.profileSaveBtn) //Edit Account - clicking on the Save button.
    }

    profileCancelLink(){
        cy.clickOnElement(profileUpdate.MyAccountElement.profileCancelLink) // Edit Account - Click on the Cancel Link.
        cy.url().should('include','/account/main') 
        return this;
    }

    profileOldPassValidation(validationMessage){
        cy.verifyContainsTextOfElement(profileUpdate.MyAccountElement.profileOldPassValidation,
            validationMessage)
        return this;
    }

    profilePasswordMismatch(validationMessage){
        cy.verifyContainsTextOfElement(profileUpdate.MyAccountElement.profilePasswordMismatch,
            validationMessage)
        return this;
    }

    profileInvalidPassSetup(validationMessage){
        cy.verifyContainsTextOfElement(profileUpdate.MyAccountElement.profileInvalidPassSetup,
            validationMessage)
        return this;
    }

    ProfileNewEmailAlert(alertMessage){
        cy.get(profileUpdate.MyAccountElement.ProfileNewEmailAlert)
        .should('be.visible')
        .and('have.text',alertMessage) //Edit Account - Email Preferences
        return this;
    }

    ProfileConfrimEmailAlert(alertMessage){
        cy.get(profileUpdate.MyAccountElement.ProfileSingleEmailAlert)
        .should('be.visible')
        .and('have.text',alertMessage) //Edit Account - Email Preferences
        return this;
    }

    ProfileSingleEmailAlert(alertMessage){
        cy.get(profileUpdate.MyAccountElement.ProfileSingleEmailAlert)
        .should('be.visible')
        .and('have.text',alertMessage) //Edit Account - Email Preferences
        return this;
    }

    profileFNameClr(){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileFName) //Edit Account - Clearing the First Name
    }

    profileLNameClr(){
        cy.clearTextElement(profileUpdate.MyAccountElement.profileLName) //Edit Account - Clearing the Last Name
    }

    profileFirstLastNameAlert(alertMessage){
        cy.verifyContainsTextOfElement(profileUpdate.MyAccountElement.profileOldPassValidation,
            alertMessage)
        return this;
    }

    ProfileLNameAlert(alertMessage){
        cy.verifyContainsTextOfElement(profileUpdate.MyAccountElement.profileOldPassValidation,
            alertMessage)
        return this;
    }
}