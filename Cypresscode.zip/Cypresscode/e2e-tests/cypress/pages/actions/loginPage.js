import { LOCATORS } from "../../pages/locators/loginPageLocators";

export function visitToEzContacts(url){
    cy.visit(url);
}

export function clickOnNoThanksButton(){
    cy.clickIfExists(LOCATORS.login.noThanksBtnPopup)
}

//Navigate to Ez-Login page
export function navigateToLoginScreen(){
    cy.get(LOCATORS.login.loginLnk).click()
}

//Use this function to login into the Ez application.
export function loginToEzContacts(username, password) {
    cy.typeTextToElement(LOCATORS.login.username, username)
    cy.typeTextToElement(LOCATORS.login.password, password)
    cy.clickOnElement(LOCATORS.login.signInBtn)
}

export function verifyUsernameIsVisible(){
    cy.verifyElementShouldBeVisible(LOCATORS.login.username)
}

export function verifyPasswordIsVisible(){
    cy.verifyElementShouldBeVisible(LOCATORS.login.password)
}

export function verifyLogoIsVisible(){   
    cy.verifyElementShouldBeVisible(LOCATORS.login.loginPageLogo)
}

export function verifyLoginSuccessMessage(message){
    cy.verifyContainsTextOfElement(LOCATORS.login.successMsg, message)
}

export function verifyAuthErrorMessage(message){
    cy.verifyContainsTextOfElement(LOCATORS.login.invalidCredMsg, message)
}