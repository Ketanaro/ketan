import { FilterReaders } from "../locators/filterreadersLocators";

export class readerFilterFunction{
    navigateToReaders(){
        cy.get('.dropdown [href="/readers"]').should('contain','Readers').click() //READER menu
        cy.url().should('include','/reader') //Validate URL
    }

    GenderMale(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.GenderMale)
    }

    GenderFemale(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.GenderFemale)
    }

    PriceUnder99(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.PriceUnder99)
    }

    PriceUnder149(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.PriceUnder149)
    }

    PriceUnder199(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.PriceUnder199)
    }

    PriceAbove200(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.PriceAbove200)
    }

    PriceAny(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.PriceAny)
    }

    ShapeCatEye(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.ShapeCatEye)
    }

    ShapeRectangle(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.ShapeRectangle)
    }

    FrameTypeFullFrame(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.FrameTypeFullFrame)
    }

    FrametypeRimless(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.FrametypeRimless)
    }

    FrametypeSemiRimless(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.FrametypeSemiRimless)
    }

    LensWidth(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.LensWidth)
    }

    ArmLength(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.ArmLength)
    }

    BridgeWidth(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.BridgeWidth)
    }

    AnySizeButton(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.AnySizeButton)
    }

    ResetFilter(){
        return cy.verifyElementShouldBeVisible(FilterReaders.readerFilters.ResetFilter)
    }
}