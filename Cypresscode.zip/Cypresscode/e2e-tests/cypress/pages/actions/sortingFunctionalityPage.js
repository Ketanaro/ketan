import { sortingFunctionality } from "../../pages/locators/sortingFunctionalityLocators"

export class sortFunction{

    navigateToEyeglasses() {
        cy.get('.dropdown [href="/eyeglasses"]').should('contain.text','EYEGLASSES').click()
        cy.url().should('include','/eyeglasses') //validate URL
        return this;
    }

    navigateToReaders(){
        cy.get('.dropdown [href="/readers"]').should('contain','Readers').click() //READER menu
        cy.url().should('include','/reader') //Validate URL
    }

    navigateToSunglasses(){
        cy.get('.dropdown [href="/sunglasses"]').should('contain.text','SUNGLASSES').click() //SUNGLASSES menu
        cy.url().should('include','/sunglasses') //Validate URL
    }
    //Use this method to select value from sorting options (only for Staging Env)
    sortOrder(sortValue){
        cy.clkToDropdown(sortingFunctionality.sortingElement.sunglassSorting,
            sortValue)
    }

    //Use this method to select value from sorting options(only for Prod. Env.)
    sortOrderProd(sortValue){
        cy.clkToDropdown(sortingFunctionality.sortingElement.prodSorting,
            sortValue)
    }

    //Get the total values from the Sorting Droprown (only for Staging Env)
    sortingValues(){
        cy.get('select#products-sort-order-select').then(($option) => {
            let value = $option.text()
            cy.log(value)
        })
    }

    //Get the total values from the Sorting Droprown for Sunglasses, Eyeglasses(only for Prod. Env.)
    prodSortValues(){
        cy.get('div.unbxd-sort-container select').then(($sortvalue) => {
            let value = $sortvalue.text()
            cy.log(value)
        })
    }

    //Get the total values from the Sorting Droprown for Reader(only for Prod. Env.)
    sortingReaderValue(){
        cy.get('select#products-sort-order-select').then(($sortvalue) => {
            let value = $sortvalue.text()
            cy.log(value)
        })
    }

    //Sort by 'Newest' value on the Product Listing page.
    verifyNewestSort(){
        cy.url().should('include','/sort:newest')  
    }

    //Sort by 'Low to High' value on the Product Listing page. (only for Staging Env)
    verifyLowPriceSort(){
        cy.url().should('include','/sort:price-low')  
    }

    //Sort by 'High to Low' value on the Product Listing page. (only for Staging Env)
    verifyHighPriceSort(){
        cy.url().should('include','/sort:price-high')
    }

    //Sort by 'Bestseller' value on the Product Listing page. (only for Staging Env)
    verifyBestsellingSun(){
        cy.url().should('include','/sunglasses')
    }

    //Sort by 'Bestseller' value on the Product Listing page. (only for Staging Env)
    verifyBestsellingEye(){
        cy.url().should('include','/eyeglasses')
    }

    //Sort by 'Bestseller' value on the Product Listing page. (only for Staging Env).
    verifyBestsellingReader(){
        cy.url().should('include','/readers')
    }

    //Sort by 'Popularity' value on the Product Listing page. (only for Prod. Env.)
    verifyPopularity(){
        cy.url().should('include','/sort:bestsellers')
    }

    //Sort by 'Name A-Z' value on the Product Listing page. (only for Prod. Env.)
    verifyNameAZ(){
        cy.url().should('include','/sort:name-az')
    }

    //Sort by 'Name Z-A' value on the Product Listing page. (only for Prod. Env.)
    verifyNameZA(){
        cy.url().should('include','/sort:name-za')
    }
}