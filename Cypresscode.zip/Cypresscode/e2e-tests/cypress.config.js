const { defineConfig } = require("cypress");

function setEnvironmentFromBaseUrl(config, url) {
  if (url.includes('local')) {
    config.env.envName = 'local';
  } else if (url.includes('staging')) {
    config.env.envName = 'staging';
  } else {
    config.env.envName = 'preprod';
  }
  config.baseUrl = url;
}

function setBaseUrlFromEnv(config, env) {
  switch (env) {
    case 'local':
      config.baseUrl = config.env.localUrl;
      break;
    case 'staging':
      config.baseUrl = config.env.stagingUrl;
      break;
    case 'preprod':
      config.baseUrl = config.env.preprodUrl;
      break;
    default:
      config.baseUrl = config.env.stagingUrl; // default to 'staging' if not found
  }
}

module.exports = defineConfig({
  projectId: "pkubhu",
  defaultCommandTimeout: 60000,
  pageLoadTimeout: 60000,
  chromeWebSecurity: false,

  e2e: {
    setupNodeEvents(on, config) {
      // Implement node event listeners here
      on('after:screenshot', (details) => {
        // Example of handling an event
        console.log(details);
      });

      // Access environment variables
      const envName = config.env.envName;
      const baseUrl = config.baseUrl;

      if (baseUrl && envName) {
        // If both baseUrl and envName are passed, use both values as provided
        config.env.envName = envName;
        config.baseUrl = baseUrl;
      } else if (envName) {
        // If only envName is passed, set baseUrl based on envName
        setBaseUrlFromEnv(config, envName);
      } else if (baseUrl) {
        // If only baseUrl is passed, set envName based on baseUrl
        setEnvironmentFromBaseUrl(config, baseUrl);
      } else {
        // If neither is passed, use defaultEnv and corresponding baseUrl
        const defaultEnv = config.env.defaultEnvName;
        config.env.envName = defaultEnv;
        setBaseUrlFromEnv(config, defaultEnv);
      }
      return config;
    },
    screenshotOnRunFailure: true, // This should be outside the setupNodeEvents function
    supportFile: 'cypress/support/e2e.js',
  },
  env: {
    defaultEnvName: "local", // default environment
    stagingUrl: "https://staging.ezcontacts.com",
    localUrl: "https://localhost:8443/",
    preprodUrl: "https://preprod.ezcontacts.com"
  }
});