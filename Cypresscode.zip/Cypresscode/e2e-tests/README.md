![Cypress](https://github.com/ezcontacts/e2e-tests/actions/workflows/cypress.yml/badge.svg)


This is a sample test setup testing with [Cypress](https://cypress.io)

You will need to have `yarn` and `nodejs` installed.

``` shell
yarn install -y
yarn cypress run
```

Then you can run the cypress application with 

``` shell
yarn cypress open
```
_PL-34- Sorting Functionality_


## Test Setup for PL-34
## _Files used in PL-34:_

1. E2E -> pdpSorting: sortingEyeglasses.cy.js, sortingSunglasses.cy.js, sortingReader.cy.js
2. Fixture - pdpSortingValues.json
    a. We stored all the values under this file.
3. Pages -> actions: sortingFunctionalityPage.js
4. Pages -> Locators: sortingFunctionalityLocators.js
4. Support - commands.js
    a. In the file, Reusable Methods.

## _Notes:_
1. We have diff. values in Staging and Production for Sorting, hence we manage this in two diff. describe block.
2. Each e2e files have 2 diff. `describe`  blocks, one is for Staging and another is for Production Env.
3. Once we build the Environment configuration, then we will manage the Describe blocks using Terminal command.
4. To run the scirpt on the Production then do the following changes:
```
Change the Env. configurion to run the code in diff. env.
Add the ".skip" to Describe block for Staging Env. Eg: describe.skip
```  

_Comment end for PL-34_

## Test Setup for PL-32
### _Files used in PL-32:_
1. E2E - myAccountEmailVerification.cy.js, myAccUpdate.cy.js, MyAccPasswordVerification.cy.js, myAccountUserPrefVerification.cy.js
2. fixtures - loginData.json, myAccountInfo.json
3. page - LoginFlow.js, myAccountUpdate.js
4. support - command.js

##Notes
1. Faker data library and Environment configuration will be handle once all the code is merged to single branch.
2. In this task, we implemented the POM framework.


_Comment end for PL-32 - My Account - Validation_
How to run test script on differnt environments:

> Environments [local, staging(default), preprod]   

> Commands to run specific script with respective env. and browser 
``` shell
yarn cypress run --spec "<test-script-path>" --env envName=<environment-name> --browser <browser-name> --headed
```
